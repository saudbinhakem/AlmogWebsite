﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class subscribers
    {
        public long Id { get; set; }
        [Display(Name ="الاسم")]
        public string? Name { get; set; }
        [Display(Name = "البريد الالكتروني")]
        public string? Email { get; set; }
        [Display(Name = "رقم الهاتف")]
        public string? phone { get; set; }
        [Display(Name = "عدد الكورسات")]
        public int? courses { get; set; }
        [Display(Name = "عدد الاشتراكات")]
        public int? sub { get; set; }
        [Display(Name = "اجمالي المبلغ المدفوع")]
        public double? amount { get; set; }
    }
}
