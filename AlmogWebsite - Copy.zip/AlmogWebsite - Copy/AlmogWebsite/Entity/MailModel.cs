﻿namespace App.Entity
{
    public class MailModel
    {
        public string Email { get; set; }
        public string body { get; set; }
        public string Subject { get; set; }
    }

    public class SenderMailInfo
    {
        public string Email { get; set; }
        public string password { get; set; }
    }
}
