﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class CourseSectionTopic
    {
        public long Id { get; set; }
        public int? CId { get; set; }

        public string? Topic { get; set; }
        [Required]
        public IFormFile? File { get; set; }
        public string? Link { get; set; }

        public int? CourseId { get; set; }

        public int? SectionId { get; set; }
    }
    public class CourseSectionTopicEdit
    {
        public long Id { get; set; }
        public int? CId { get; set; }

        public string? Topic { get; set; }
        public IFormFile? File { get; set; }
        public string? Link { get; set; }

        public int? CourseId { get; set; }

        public int? SectionId { get; set; }
    }
}
