﻿namespace App.Entity
{
    public class Blog
    {
        public int Id { get; set; }
        public string? Text { get; set; }
        public string Lang { get; set; }
        
        public string? icon { get; set; }
        public string? WriteDate { get; set; }
    }
}
