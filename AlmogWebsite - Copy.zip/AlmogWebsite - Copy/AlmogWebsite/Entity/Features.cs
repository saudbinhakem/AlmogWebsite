﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class Features:Blog
    {
        public IFormFile? File {  get; set; }
        [Required]
        public string EnName { get; set; }
    }
}
