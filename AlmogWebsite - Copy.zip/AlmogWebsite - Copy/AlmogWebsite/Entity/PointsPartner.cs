﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class PointsPartner
    {
        public int Id { get; set; }
        [Required]
        public string? Name { get; set; }
         [Required]
        public string? EnName { get; set; }

        public string? Icon { get; set; }
        [Required]
        public IFormFile? File { get; set; }
        [Required]
        public string? Overview { get; set; }
        [Required]
        public string? EnOverview { get; set; }
        [Required]
        public string? StoreLink { get; set; }
        [Required]
        public string? BnifitfmPoints { get; set; }
        [Required]
        public string? EnBnifitfmPoints { get; set; }

        [Display(Name = "لموقع x")]
        public string? Lat { get; set; } = null!;
        [Display(Name = "الموقع y")]
        public string? lng { get; set; } = null!;
    }
    public class PointsPartnerEdit
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string? Name { get; set; }
        [Required]
        public string? EnName { get; set; }
        [Required]
        public string? Overview { get; set; }
        [Required]
        public string? EnOverview { get; set; }
        [Required]
        public string? StoreLink { get; set; }
        [Required]
        public string? BnifitfmPoints { get; set; }
        [Required]
        public string? EnBnifitfmPoints { get; set; }
        public string? Icon { get; set; }
        [Display(Name = "لموقع x")]
        public string? Lat { get; set; } = null!;
        [Display(Name = "الموقع y")]
        public string? lng { get; set; } = null!;
        public string? mapName { get; set; } = null!;
        public IFormFile? File { get; set; }
    }
}
