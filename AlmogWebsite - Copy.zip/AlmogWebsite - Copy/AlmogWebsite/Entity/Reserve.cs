﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class Reserve
    {
        [Required]
        public string? subject { get; set; }
        public int? Id { get; set; }
        //[Required]
        //public string? subject { get; set; }
        [Required]
        public string? Name { get; set; }
       
        [Required]
        [RegularExpression(@"^9665\d{8}$", ErrorMessage = "رقم الهاتف يجب ان يكون 9 ارقام تبداء ب 5  بالاضافة مفتاح البلد")]

        public string? Phone { get; set; }
        [Required]
        [EmailAddress(ErrorMessage = "يجب ادخال ايميل صحيح")]
        public string? email { get; set; }
    }
}
