﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public static class GlobalData
    {
        public static string Phone { get; set; }
      
        public static string email { get; set; }
        public static string LinkedIn { get; set; }
        public static string twitter { get; set; }
        public static string facebook { get; set; }
        public static string insta { get; set; }
    }
}
