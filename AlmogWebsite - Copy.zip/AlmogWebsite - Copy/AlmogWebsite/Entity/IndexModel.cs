﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class IndexModel
    {
        public long Id { get; set; }
        public string? Vision { get; set; }
        public string? Defination { get; set; }
        public string? EnVision { get; set; }
        public string? EnDefination { get; set; }
        public string? phoneNo { get; set; }

     
      
        public string? LinkedIn { get; set; }
      
        public string? facebook { get; set; }
        public string? Whatsapp { get; set; }
     
        public string? Email { get; set; }
      
       

        public string? Location { get; set; }
        

        public string? appGoogleLink { get; set; }
        public string? appAppleLink { get; set; }
     
        public List<Entity.Blog>? blog { get; set; }
        public List<Entity.Features>? features { get; set; }
        [Required]
        public string? Message { get; set; }
        //[Required]
        //public string? subject { get; set; }
        [Required]

        public string? Name { get; set; }
        [Required]
        public string? Phone { get; set; }
        [Required]
        [EmailAddress(ErrorMessage = "يجب ادخال ايميل صحيح")]
        public string? email { get; set; }

    }
    public class PostIndexModel
    {
        [Required]
        public string? Vision { get; set; }
        [Required]
        public string? Defination { get; set; }
        [Required]
        public string? EnVision { get; set; }
        [Required]
        public string? EnDefination { get; set; }
        [Required]
        public string? phoneNo { get; set; }
        [Required]
        public string? LinkedIn { get; set; }
        //[Required]
        //public string? twitter { get; set; }
        [Required]
        public string? facebook { get; set; }
        [Required]
        public string? whatsapp { get; set; }
        [Required]
        public string? Email { get; set; }
       

        //[Required]
        //public string? Location { get; set; }
      

        //public string? appGoogleLink { get; set; }
        //public string? appAppleLink { get; set; }

  
    }
}
