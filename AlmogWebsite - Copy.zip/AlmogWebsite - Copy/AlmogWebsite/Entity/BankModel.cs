﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class BankModel
    {
        public int Id { get; set; }
        [Required]
        public string? BankName { get; set; }
        [Required]
        public string? EnBankName { get; set; }
        [Required]
        public string? ConnectionCode { get; set; }
        [Required]
        public string? OperationDetils { get; set; }
    }
}
