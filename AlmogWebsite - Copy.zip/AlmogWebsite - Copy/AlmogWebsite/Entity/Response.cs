﻿namespace App.Entity
{
    public class Response
    {
        public bool error { get; set; }
        public string message { get; set; }
        public int state { get; set; }
        public string url { get; set; }
        public object data { get; set; }=new object();
    }
}
