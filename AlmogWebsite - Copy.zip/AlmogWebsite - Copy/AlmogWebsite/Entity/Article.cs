﻿using System.ComponentModel.DataAnnotations;

namespace App.Entity
{
    public class Article 
    {
        public int? Id { get; set; }
        [Required]
        public string? Title { get; set; }
        [Required]
        public string? OverView { get; set; }
        [Required]
        public string? Body { get; set; }

    }

    public class ArticlePostModel: Article
    {
        
        [Required]
        public List<IFormFile>? img { get; set; }
        [Required]
        public string? Lang { get; set; }
    } 
    public class ArticleUpdateModel: Article
    {
        public string? WriteDate { get; set; }

        public List<IFormFile>? img { get; set; }

        public List<ImagesModel>? imgUrls { get; set; }
        [Required]
        public string? Lang { get; set; }
    }


    public class ArticleModel {
        [Required]
        public string? Title { get; set; }
        [Required]
        public string? OverView { get; set; }
        [Required]
        public string? Body { get; set; }
        [Required]
        public string? Author { get; set; }
        public string? Catgory { get; set; }
    }

    public class ImagesModel
    {
        public int imgId { get; set; }
        public string imgUrl { get; set; }
    }

    public class ArticleAddModel: ArticleModel
    {
       
        //[Required]
       
       
        [Required]
        public IFormFile? DisplayImage { get; set; }
        public IFormFile? DetailsImage { get; set; }
        [Required]
        public IFormFile? AuthorImg { get; set; }
       
       

        public bool? IsActive { get; set; }
    }

    public class ArticleEditModel:ArticleModel
    {
        [Required]
        public int Id { get; set; }
        public IFormFile? DisplayImage { get; set; }
        public string? DisplayImageURL { get; set; }


        public IFormFile? DetailsImage { get; set; }
        public string? DetailsImageURL { get; set; }
        public IFormFile? AuthorImg { get; set; }
        public string? AuthorImgURL { get; set; }
       
      

        public bool? IsActive { get; set; }
        
    }
}