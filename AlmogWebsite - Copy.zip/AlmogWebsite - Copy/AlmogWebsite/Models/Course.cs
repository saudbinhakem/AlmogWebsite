﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class Course
{
    public int Id { get; set; }

    public string? Titel { get; set; }

    public string? Defination { get; set; }

    public string? Trainer { get; set; }

    public string? Language { get; set; }

    public double? Price { get; set; }

    public string? Currency { get; set; }

    public string? Coupon { get; set; }

    public string? Topics { get; set; }

    public DateTime? CreateDate { get; set; }

    public string Lang { get; set; } = null!;

    public double? CouponDiscount { get; set; }

    public virtual ICollection<CourseComment> CourseComments { get; set; } = new List<CourseComment>();

    public virtual ICollection<CourseCoupon> CourseCoupons { get; set; } = new List<CourseCoupon>();

    public virtual ICollection<CourseLike> CourseLikes { get; set; } = new List<CourseLike>();

    public virtual ICollection<CourseSectionTopic> CourseSectionTopics { get; set; } = new List<CourseSectionTopic>();

    public virtual ICollection<CourseVideo> CourseVideos { get; set; } = new List<CourseVideo>();

    public virtual ICollection<Subscription> Subscriptions { get; set; } = new List<Subscription>();
}
