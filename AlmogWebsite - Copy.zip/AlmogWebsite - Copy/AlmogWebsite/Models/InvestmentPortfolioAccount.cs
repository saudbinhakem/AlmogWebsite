﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class InvestmentPortfolioAccount
{
    public long Id { get; set; }

    public long? Ipid { get; set; }

    public long? UserId { get; set; }

    public long? UserAccId { get; set; }

    public int? BankId { get; set; }

    public double? Deduction { get; set; }

    public DateTime? OperationDate { get; set; }

    public double? DeductionRate { get; set; }

    public string? State { get; set; }

    public bool? IsActive { get; set; }

    public virtual ICollection<InvestmentPortfolioTransaction> InvestmentPortfolioTransactions { get; set; } = new List<InvestmentPortfolioTransaction>();

    public virtual InvestmentPortfolio? Ip { get; set; }
}
