﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class PayingCompaniesTable
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? ConnectionCode { get; set; }

    public string? OperationDetils { get; set; }

    public bool Deleted { get; set; }
}
