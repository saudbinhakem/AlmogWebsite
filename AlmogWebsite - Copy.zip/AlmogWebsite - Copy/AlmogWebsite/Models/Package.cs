﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class Package
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? Characters { get; set; }

    public double? Price { get; set; }

    public string? Period { get; set; }

    public string? State { get; set; }

    public bool? IsActive { get; set; }

    public DateTime? CreateOn { get; set; }

    public long? MasterId { get; set; }

    public int? PackageDays { get; set; }

    public string? EnName { get; set; }

    public string? EnCharacters { get; set; }

    public string? EnPeriod { get; set; }

    public virtual ICollection<Subscription> Subscriptions { get; set; } = new List<Subscription>();
}
