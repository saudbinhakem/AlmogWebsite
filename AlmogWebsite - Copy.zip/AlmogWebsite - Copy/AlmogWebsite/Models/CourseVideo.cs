﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class CourseVideo
{
    public int Id { get; set; }

    public int CourseId { get; set; }

    public string? Link { get; set; }

    public string? Name { get; set; }

    public string? State { get; set; }

    public int? ViewsNo { get; set; }

    public bool Deleted { get; set; }

    public virtual Course Course { get; set; } = null!;
}
