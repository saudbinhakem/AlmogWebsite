﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class CourseComment
{
    public long Id { get; set; }

    public string? Comment { get; set; }

    public long? UserId { get; set; }

    public int? CourseId { get; set; }

    public DateTime? CommDate { get; set; }

    public string? Temp1 { get; set; }

    public string? Temp2 { get; set; }

    public bool? Deleted { get; set; }

    public virtual Course? Course { get; set; }

    public virtual SystemUser? User { get; set; }
}
