﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AlmogWebsite.Models;

public partial class AlmogdatabaseContext : DbContext
{
    public AlmogdatabaseContext()
    {
    }

    public AlmogdatabaseContext(DbContextOptions<AlmogdatabaseContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Article> Articles { get; set; }

    public virtual DbSet<ArticlesImage> ArticlesImages { get; set; }

    public virtual DbSet<AspNetRole> AspNetRoles { get; set; }

    public virtual DbSet<AspNetRoleClaim> AspNetRoleClaims { get; set; }

    public virtual DbSet<AspNetUser> AspNetUsers { get; set; }

    public virtual DbSet<AspNetUserClaim> AspNetUserClaims { get; set; }

    public virtual DbSet<AspNetUserLogin> AspNetUserLogins { get; set; }

    public virtual DbSet<AspNetUserToken> AspNetUserTokens { get; set; }

    public virtual DbSet<BankAccountTransction> BankAccountTransctions { get; set; }

    public virtual DbSet<BanksAccount> BanksAccounts { get; set; }

    public virtual DbSet<Blog> Blogs { get; set; }

    public virtual DbSet<ConnectBanksOtpCode> ConnectBanksOtpCodes { get; set; }

    public virtual DbSet<ContactU> ContactUs { get; set; }

    public virtual DbSet<Course> Courses { get; set; }

    public virtual DbSet<CourseComment> CourseComments { get; set; }

    public virtual DbSet<CourseCoupon> CourseCoupons { get; set; }

    public virtual DbSet<CourseLike> CourseLikes { get; set; }

    public virtual DbSet<CourseSection> CourseSections { get; set; }

    public virtual DbSet<CourseSectionTopic> CourseSectionTopics { get; set; }

    public virtual DbSet<CourseVideo> CourseVideos { get; set; }

    public virtual DbSet<DiscountsTable> DiscountsTables { get; set; }

    public virtual DbSet<Feature> Features { get; set; }

    public virtual DbSet<GrantedDiscount> GrantedDiscounts { get; set; }

    public virtual DbSet<InvestmentPortfolio> InvestmentPortfolios { get; set; }

    public virtual DbSet<InvestmentPortfolioAccount> InvestmentPortfolioAccounts { get; set; }

    public virtual DbSet<InvestmentPortfolioTransaction> InvestmentPortfolioTransactions { get; set; }

    public virtual DbSet<OffersAndCopun> OffersAndCopuns { get; set; }

    public virtual DbSet<OrderedGrantedDiscount> OrderedGrantedDiscounts { get; set; }

    public virtual DbSet<Otplogin> Otplogins { get; set; }

    public virtual DbSet<Otpsm> Otpsms { get; set; }

    public virtual DbSet<Package> Packages { get; set; }

    public virtual DbSet<PayingCompaniesTable> PayingCompaniesTables { get; set; }

    public virtual DbSet<PointReplaceOrder> PointReplaceOrders { get; set; }

    public virtual DbSet<PointsPartner> PointsPartners { get; set; }

    public virtual DbSet<PointsTable> PointsTables { get; set; }

    public virtual DbSet<SiteInfo> SiteInfos { get; set; }

    public virtual DbSet<Subscription> Subscriptions { get; set; }

    public virtual DbSet<SystemUser> SystemUsers { get; set; }

    public virtual DbSet<UserBanksAccount> UserBanksAccounts { get; set; }

    public virtual DbSet<UserPointsPartenr> UserPointsPartenrs { get; set; }

    public virtual DbSet<UserPointsTransction> UserPointsTransctions { get; set; }

    public virtual DbSet<Walet> Walets { get; set; }

    public virtual DbSet<WaletTransction> WaletTransctions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        //=> optionsBuilder.UseSqlServer("Server=SQL8006.site4now.net;Initial Catalog=db_aa9eb8_almogdb;User Id=db_aa9eb8_almogdb_admin;Password=B570@Com");
        => optionsBuilder.UseSqlServer("Server=.;Database=Almogdatabase;Trusted_Connection=True; TrustServerCertificate=true;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.UseCollation("Arabic_CI_AS");

        modelBuilder.Entity<Article>(entity =>
        {
            entity.Property(e => e.Author).HasMaxLength(1500);
            entity.Property(e => e.Catgory).HasMaxLength(1500);
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.IsActive).HasMaxLength(50);
            entity.Property(e => e.Lang)
                .HasMaxLength(5)
                .HasDefaultValue("ar")
                .HasColumnName("lang");
            entity.Property(e => e.OverView).HasMaxLength(1500);
            entity.Property(e => e.Title).HasMaxLength(500);
            entity.Property(e => e.WriteDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<ArticlesImage>(entity =>
        {
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.Link)
                .HasMaxLength(1500)
                .HasColumnName("link");
            entity.Property(e => e.Name).HasColumnName("name");
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .HasColumnName("state");

            entity.HasOne(d => d.Art).WithMany(p => p.ArticlesImages)
                .HasForeignKey(d => d.ArtId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Articles_ArticlesImages_ArtId");
        });

        modelBuilder.Entity<AspNetRole>(entity =>
        {
            entity.HasIndex(e => e.NormalizedName, "RoleNameIndex")
                .IsUnique()
                .HasFilter("([NormalizedName] IS NOT NULL)");

            entity.Property(e => e.Name).HasMaxLength(256);
            entity.Property(e => e.NormalizedName).HasMaxLength(256);
        });

        modelBuilder.Entity<AspNetRoleClaim>(entity =>
        {
            entity.HasIndex(e => e.RoleId, "IX_AspNetRoleClaims_RoleId");

            entity.HasOne(d => d.Role).WithMany(p => p.AspNetRoleClaims).HasForeignKey(d => d.RoleId);
        });

        modelBuilder.Entity<AspNetUser>(entity =>
        {
            entity.HasIndex(e => e.NormalizedEmail, "EmailIndex");

            entity.HasIndex(e => e.NormalizedUserName, "UserNameIndex")
                .IsUnique()
                .HasFilter("([NormalizedUserName] IS NOT NULL)");

            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.NormalizedEmail).HasMaxLength(256);
            entity.Property(e => e.NormalizedUserName).HasMaxLength(256);
            entity.Property(e => e.RefreshTokenExpiryTime).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.UserName).HasMaxLength(256);

            entity.HasMany(d => d.Roles).WithMany(p => p.Users)
                .UsingEntity<Dictionary<string, object>>(
                    "AspNetUserRole",
                    r => r.HasOne<AspNetRole>().WithMany().HasForeignKey("RoleId"),
                    l => l.HasOne<AspNetUser>().WithMany().HasForeignKey("UserId"),
                    j =>
                    {
                        j.HasKey("UserId", "RoleId");
                        j.ToTable("AspNetUserRoles");
                        j.HasIndex(new[] { "RoleId" }, "IX_AspNetUserRoles_RoleId");
                    });
        });

        modelBuilder.Entity<AspNetUserClaim>(entity =>
        {
            entity.HasIndex(e => e.UserId, "IX_AspNetUserClaims_UserId");

            entity.HasOne(d => d.User).WithMany(p => p.AspNetUserClaims).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<AspNetUserLogin>(entity =>
        {
            entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });

            entity.HasIndex(e => e.UserId, "IX_AspNetUserLogins_UserId");

            entity.Property(e => e.LoginProvider).HasMaxLength(128);
            entity.Property(e => e.ProviderKey).HasMaxLength(128);

            entity.HasOne(d => d.User).WithMany(p => p.AspNetUserLogins).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<AspNetUserToken>(entity =>
        {
            entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });

            entity.Property(e => e.LoginProvider).HasMaxLength(128);
            entity.Property(e => e.Name).HasMaxLength(128);

            entity.HasOne(d => d.User).WithMany(p => p.AspNetUserTokens).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<BankAccountTransction>(entity =>
        {
            entity.Property(e => e.AccId).HasColumnName("Acc_Id");
            entity.Property(e => e.DateOfOp)
                .HasColumnType("datetime")
                .HasColumnName("DateOfOP");
            entity.Property(e => e.DistAccNo).HasMaxLength(250);
            entity.Property(e => e.Note).HasMaxLength(1500);
            entity.Property(e => e.OpType).HasMaxLength(50);
            entity.Property(e => e.Purpose).HasMaxLength(1500);
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .HasColumnName("state");
            entity.Property(e => e.Temp1)
                .HasMaxLength(250)
                .HasColumnName("temp1");
            entity.Property(e => e.Temp2)
                .HasMaxLength(250)
                .HasColumnName("temp2");
        });

        modelBuilder.Entity<BanksAccount>(entity =>
        {
            entity.ToTable("BanksAccount");

            entity.Property(e => e.AccountNumber).HasMaxLength(150);
            entity.Property(e => e.Active).HasColumnName("active");
            entity.Property(e => e.BankName).HasMaxLength(150);
            entity.Property(e => e.ConnectionCode).HasMaxLength(500);
            entity.Property(e => e.CreateOn).HasColumnType("datetime");
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.EnBankName).HasMaxLength(150);
            entity.Property(e => e.Icon).HasMaxLength(250);
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .HasDefaultValue("A")
                .HasColumnName("state");
            entity.Property(e => e.Target)
                .HasMaxLength(50)
                .HasDefaultValue("control")
                .HasColumnName("target");
        });

        modelBuilder.Entity<Blog>(entity =>
        {
            entity.ToTable("Blog");

            entity.Property(e => e.Author).HasMaxLength(1500);
            entity.Property(e => e.AuthorImg).HasMaxLength(1500);
            entity.Property(e => e.Catgory).HasMaxLength(1500);
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.DisplayImage).HasMaxLength(1500);
            entity.Property(e => e.IsActive).HasMaxLength(50);
            entity.Property(e => e.Lang)
                .HasMaxLength(5)
                .HasDefaultValue("ar")
                .HasColumnName("lang");
            entity.Property(e => e.OverView).HasMaxLength(1500);
            entity.Property(e => e.Title).HasMaxLength(500);
            entity.Property(e => e.WriteDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<ConnectBanksOtpCode>(entity =>
        {
            entity.Property(e => e.CreateDate)
                .HasColumnType("datetime")
                .HasColumnName("createDate");
            entity.Property(e => e.IsAuth).HasColumnName("isAuth");
            entity.Property(e => e.OtpId).HasColumnName("otpId");

            entity.HasOne(d => d.Bank).WithMany(p => p.ConnectBanksOtpCodes)
                .HasForeignKey(d => d.BankId)
                .HasConstraintName("FK_ConnectBanksOtpCodes_BanksAccount");

            entity.HasOne(d => d.Otp).WithMany(p => p.ConnectBanksOtpCodes)
                .HasForeignKey(d => d.OtpId)
                .HasConstraintName("FK_ConnectBanksOtpCodes_OTPLogins");

            entity.HasOne(d => d.User).WithMany(p => p.ConnectBanksOtpCodes)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_ConnectBanksOtpCodes_SystemUsers");
        });

        modelBuilder.Entity<ContactU>(entity =>
        {
            entity.Property(e => e.Email).HasMaxLength(20);
            entity.Property(e => e.IsRead).HasColumnName("isRead");
            entity.Property(e => e.IsReplay).HasColumnName("isReplay");
            entity.Property(e => e.Message).HasColumnName("message");
            entity.Property(e => e.Name).HasMaxLength(500);
            entity.Property(e => e.OrderDate).HasColumnType("datetime");
            entity.Property(e => e.PhoneNo)
                .HasMaxLength(50)
                .HasColumnName("phoneNo");
            entity.Property(e => e.Subject).HasMaxLength(250);
        });

        modelBuilder.Entity<Course>(entity =>
        {
            entity.Property(e => e.Coupon).HasMaxLength(50);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Currency).HasMaxLength(50);
            entity.Property(e => e.Lang)
                .HasMaxLength(5)
                .HasDefaultValue("ar")
                .HasColumnName("lang");
            entity.Property(e => e.Language).HasMaxLength(250);
            entity.Property(e => e.Titel).HasMaxLength(1500);
        });

        modelBuilder.Entity<CourseComment>(entity =>
        {
            entity.Property(e => e.CommDate).HasColumnType("datetime");
            entity.Property(e => e.Comment).HasMaxLength(1500);
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.Temp1)
                .HasMaxLength(500)
                .HasColumnName("temp1");
            entity.Property(e => e.Temp2)
                .HasMaxLength(500)
                .HasColumnName("temp2");

            entity.HasOne(d => d.Course).WithMany(p => p.CourseComments)
                .HasForeignKey(d => d.CourseId)
                .HasConstraintName("FK_CourseComments_Courses");

            entity.HasOne(d => d.User).WithMany(p => p.CourseComments)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_CourseComments_SystemUsers");
        });

        modelBuilder.Entity<CourseCoupon>(entity =>
        {
            entity.ToTable("CourseCoupon");

            entity.Property(e => e.CouponCode)
                .HasMaxLength(1500)
                .HasColumnName("couponCode");
            entity.Property(e => e.Datetime)
                .HasColumnType("datetime")
                .HasColumnName("datetime");
            entity.Property(e => e.Discount).HasColumnName("discount");

            entity.HasOne(d => d.Course).WithMany(p => p.CourseCoupons)
                .HasForeignKey(d => d.CourseId)
                .HasConstraintName("FK_CourseCoupon_Courses");
        });

        modelBuilder.Entity<CourseLike>(entity =>
        {
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.Temp1)
                .HasMaxLength(500)
                .HasColumnName("temp1");
            entity.Property(e => e.Temp2)
                .HasMaxLength(500)
                .HasColumnName("temp2");

            entity.HasOne(d => d.Course).WithMany(p => p.CourseLikes)
                .HasForeignKey(d => d.CourseId)
                .HasConstraintName("FK_CourseLikes_Courses");

            entity.HasOne(d => d.User).WithMany(p => p.CourseLikes)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_CourseLikes_SystemUsers");
        });

        modelBuilder.Entity<CourseSection>(entity =>
        {
            entity.Property(e => e.Datetime)
                .HasColumnType("datetime")
                .HasColumnName("datetime");
            entity.Property(e => e.SectionContent).HasMaxLength(1500);
            entity.Property(e => e.SectionName).HasMaxLength(500);
            entity.Property(e => e.VideoLink).HasMaxLength(1500);
        });

        modelBuilder.Entity<CourseSectionTopic>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_CousreSectionTopics");

            entity.Property(e => e.Link).HasMaxLength(1500);
            entity.Property(e => e.Topic).HasMaxLength(1500);

            entity.HasOne(d => d.Course).WithMany(p => p.CourseSectionTopics)
                .HasForeignKey(d => d.CourseId)
                .HasConstraintName("FK_CousreSectionTopics_Courses");

            entity.HasOne(d => d.Section).WithMany(p => p.CourseSectionTopics)
                .HasForeignKey(d => d.SectionId)
                .HasConstraintName("FK_CousreSectionTopics_CourseSections");
        });

        modelBuilder.Entity<CourseVideo>(entity =>
        {
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.Link)
                .HasMaxLength(1500)
                .HasColumnName("link");
            entity.Property(e => e.Name).HasColumnName("name");
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .HasColumnName("state");
            entity.Property(e => e.ViewsNo).HasColumnName("viewsNo");

            entity.HasOne(d => d.Course).WithMany(p => p.CourseVideos)
                .HasForeignKey(d => d.CourseId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Course_CourseVideos_courseId");
        });

        modelBuilder.Entity<DiscountsTable>(entity =>
        {
            entity.Property(e => e.Deleted).HasDefaultValue(false);
            entity.Property(e => e.DisCountName).HasMaxLength(250);
            entity.Property(e => e.DiscImg)
                .HasMaxLength(250)
                .HasColumnName("discImg");
            entity.Property(e => e.DiscountCode).HasMaxLength(250);
            entity.Property(e => e.GrantDiscount).HasDefaultValue(true);
            entity.Property(e => e.GrantType).HasMaxLength(50);
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("isActive");
            entity.Property(e => e.MasterId).HasColumnName("masterId");
            entity.Property(e => e.Orderdate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("orderdate");
            entity.Property(e => e.Orderstate)
                .HasMaxLength(50)
                .HasColumnName("orderstate");

            entity.HasOne(d => d.Master).WithMany(p => p.DiscountsTableMasters)
                .HasForeignKey(d => d.MasterId)
                .HasConstraintName("FK_DiscountsTables_SystemUsers1");

            entity.HasOne(d => d.User).WithMany(p => p.DiscountsTableUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_DiscountsTables_SystemUsers");
        });

        modelBuilder.Entity<Feature>(entity =>
        {
            entity.Property(e => e.Active).HasColumnName("active");
            entity.Property(e => e.EnName).HasMaxLength(1500);
            entity.Property(e => e.Icon)
                .HasMaxLength(500)
                .HasColumnName("icon");
            entity.Property(e => e.Name).HasMaxLength(1500);
        });

        modelBuilder.Entity<GrantedDiscount>(entity =>
        {
            entity.Property(e => e.GrantDate).HasColumnType("datetime");
            entity.Property(e => e.OrderState)
                .HasMaxLength(20)
                .HasDefaultValue("new");
            entity.Property(e => e.Replaced).HasColumnName("replaced");

            entity.HasOne(d => d.Product).WithMany(p => p.GrantedDiscounts)
                .HasForeignKey(d => d.ProductId)
                .HasConstraintName("FK_GrantedDiscounts_DiscountsTables");

            entity.HasOne(d => d.Provider).WithMany(p => p.GrantedDiscountProviders)
                .HasForeignKey(d => d.ProviderId)
                .HasConstraintName("FK_GrantedDiscounts_SystemUsersProvider");

            entity.HasOne(d => d.User).WithMany(p => p.GrantedDiscountUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_GrantedDiscounts_SystemUsers");
        });

        modelBuilder.Entity<InvestmentPortfolio>(entity =>
        {
            entity.ToTable("InvestmentPortfolio");

            entity.Property(e => e.ConectDate).HasColumnType("datetime");
            entity.Property(e => e.DisconectDate).HasColumnType("datetime");
            entity.Property(e => e.Note).HasMaxLength(500);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .HasColumnName("status");

            entity.HasOne(d => d.User).WithMany(p => p.InvestmentPortfolios)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_InvestmentPortfolio_SystemUsers");
        });

        modelBuilder.Entity<InvestmentPortfolioAccount>(entity =>
        {
            entity.Property(e => e.Ipid).HasColumnName("IPId");
            entity.Property(e => e.IsActive).HasColumnName("isActive");
            entity.Property(e => e.OperationDate)
                .HasColumnType("datetime")
                .HasColumnName("operationDate");
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .HasColumnName("state");

            entity.HasOne(d => d.Ip).WithMany(p => p.InvestmentPortfolioAccounts)
                .HasForeignKey(d => d.Ipid)
                .HasConstraintName("FK_InvestmentPortfolioAccounts_InvestmentPortfolio");
        });

        modelBuilder.Entity<InvestmentPortfolioTransaction>(entity =>
        {
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnType("decimal(18, 0)");
            entity.Property(e => e.Ipid).HasColumnName("IPId");
            entity.Property(e => e.OperationDate)
                .HasColumnType("datetime")
                .HasColumnName("operationDate");
            entity.Property(e => e.Temp1)
                .HasMaxLength(50)
                .HasColumnName("temp1");
            entity.Property(e => e.Temp2)
                .HasMaxLength(50)
                .HasColumnName("temp2");

            entity.HasOne(d => d.Account).WithMany(p => p.InvestmentPortfolioTransactions)
                .HasForeignKey(d => d.AccountId)
                .HasConstraintName("FK_InvestmentPortfolioTransactions_InvestmentPortfolioAccounts");

            entity.HasOne(d => d.Ip).WithMany(p => p.InvestmentPortfolioTransactions)
                .HasForeignKey(d => d.Ipid)
                .HasConstraintName("FK_InvestmentPortfolioTransactions_InvestmentPortfolio");

            entity.HasOne(d => d.User).WithMany(p => p.InvestmentPortfolioTransactions)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_InvestmentPortfolioTransactions_SystemUsers");
        });

        modelBuilder.Entity<OffersAndCopun>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_SpecialOffers");

            entity.Property(e => e.CopunCode).HasMaxLength(20);
            entity.Property(e => e.Details).HasMaxLength(1500);
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.Img).HasMaxLength(500);
            entity.Property(e => e.IsActive).HasColumnName("isActive");
            entity.Property(e => e.Name).HasMaxLength(500);
            entity.Property(e => e.OverView)
                .HasMaxLength(500)
                .HasColumnName("overView");
            entity.Property(e => e.RecType)
                .HasMaxLength(20)
                .HasDefaultValue("offer")
                .HasColumnName("recType");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.StoreLink).HasMaxLength(500);
        });

        modelBuilder.Entity<OrderedGrantedDiscount>(entity =>
        {
            entity.Property(e => e.Gdid).HasColumnName("GDId");

            entity.HasOne(d => d.Gd).WithMany(p => p.OrderedGrantedDiscounts)
                .HasForeignKey(d => d.Gdid)
                .HasConstraintName("FK_OrderedGrantedDiscounts_GrantedDiscounts");

            entity.HasOne(d => d.Order).WithMany(p => p.OrderedGrantedDiscounts)
                .HasForeignKey(d => d.OrderId)
                .HasConstraintName("FK_OrderedGrantedDiscounts_PointReplaceOrders");
        });

        modelBuilder.Entity<Otplogin>(entity =>
        {
            entity.ToTable("OTPLogins");

            entity.Property(e => e.Aspid)
                .HasMaxLength(450)
                .HasColumnName("ASPId");
            entity.Property(e => e.Date).HasColumnType("datetime");
            entity.Property(e => e.IsCurrent).HasColumnName("isCurrent");
            entity.Property(e => e.IsPassChanged).HasColumnName("isPassChanged");
            entity.Property(e => e.IsVerify).HasColumnName("isVerify");
            entity.Property(e => e.OtpTime).HasColumnName("otpTime");
            entity.Property(e => e.Otpcode).HasColumnName("OTPCode");
            entity.Property(e => e.Otphash).HasColumnName("otphash");
            entity.Property(e => e.PhoneNo).HasMaxLength(50);
            entity.Property(e => e.Purpose)
                .HasMaxLength(50)
                .HasDefaultValue("R")
                .HasColumnName("purpose");

            entity.HasOne(d => d.User).WithMany(p => p.Otplogins)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_OTPLogins_SystemUsers");
        });

        modelBuilder.Entity<Otpsm>(entity =>
        {
            entity.ToTable("OTPSMS");

            entity.Property(e => e.Code)
                .HasMaxLength(50)
                .HasColumnName("code");
            entity.Property(e => e.Date)
                .HasColumnType("datetime")
                .HasColumnName("date");
            entity.Property(e => e.Message).HasColumnName("message");
            entity.Property(e => e.MsgId).HasMaxLength(50);
            entity.Property(e => e.Responce).HasColumnName("responce");
            entity.Property(e => e.SendStatus).HasColumnName("sendStatus");
            entity.Property(e => e.Status).HasColumnName("status");
        });

        modelBuilder.Entity<Package>(entity =>
        {
            entity.Property(e => e.Characters).HasColumnName("characters");
            entity.Property(e => e.CreateOn).HasColumnType("datetime");
            entity.Property(e => e.EnName).HasMaxLength(1500);
            entity.Property(e => e.EnPeriod).HasMaxLength(1500);
            entity.Property(e => e.IsActive).HasColumnName("isActive");
            entity.Property(e => e.MasterId).HasColumnName("masterId");
            entity.Property(e => e.Name).HasMaxLength(1500);
            entity.Property(e => e.Period).HasMaxLength(250);
            entity.Property(e => e.State).HasMaxLength(50);
        });

        modelBuilder.Entity<PayingCompaniesTable>(entity =>
        {
            entity.ToTable("PayingCompaniesTable");

            entity.Property(e => e.ConnectionCode).HasMaxLength(250);
            entity.Property(e => e.Deleted).HasColumnName("deleted");
            entity.Property(e => e.Name).HasMaxLength(250);
            entity.Property(e => e.OperationDetils).HasMaxLength(1500);
        });

        modelBuilder.Entity<PointReplaceOrder>(entity =>
        {
            entity.Property(e => e.AgentName).HasMaxLength(500);
            entity.Property(e => e.OrderDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.State)
                .HasMaxLength(500)
                .HasDefaultValue("wait")
                .HasColumnName("state");

            entity.HasOne(d => d.Provider).WithMany(p => p.PointReplaceOrderProviders)
                .HasForeignKey(d => d.ProviderId)
                .HasConstraintName("FK_PointReplaceOrders_SystemUsersProvider");

            entity.HasOne(d => d.User).WithMany(p => p.PointReplaceOrderUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_PointReplaceOrders_SystemUsersUser");
        });

        modelBuilder.Entity<PointsPartner>(entity =>
        {
            entity.Property(e => e.BnifitfmPoints).HasMaxLength(1500);
            entity.Property(e => e.EnBnifitfmPoints).HasMaxLength(1500);
            entity.Property(e => e.EnName).HasMaxLength(500);
            entity.Property(e => e.EnOverview).HasMaxLength(1500);
            entity.Property(e => e.Icon).HasMaxLength(1500);
            entity.Property(e => e.Lat)
                .HasMaxLength(50)
                .HasColumnName("lat");
            entity.Property(e => e.Lng)
                .HasMaxLength(50)
                .HasColumnName("lng");
            entity.Property(e => e.Name).HasMaxLength(500);
            entity.Property(e => e.Overview).HasMaxLength(1500);
            entity.Property(e => e.StoreLink).HasMaxLength(1500);
        });

        modelBuilder.Entity<PointsTable>(entity =>
        {
            entity.Property(e => e.Deleted).HasDefaultValue(false);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Discount).WithMany(p => p.PointsTables)
                .HasForeignKey(d => d.DiscountId)
                .HasConstraintName("FK_PointsTables_DiscountsTables");

            entity.HasOne(d => d.User).WithMany(p => p.PointsTables)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_PointsTables_SystemUsers");
        });

        modelBuilder.Entity<SiteInfo>(entity =>
        {
            entity.ToTable("SiteInfo");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AppLinkApple)
                .HasMaxLength(500)
                .HasColumnName("appLinkApple");
            entity.Property(e => e.AppLinkGoogle)
                .HasMaxLength(500)
                .HasColumnName("appLinkGoogle");
            entity.Property(e => e.Customers).HasMaxLength(20);
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Experts).HasMaxLength(50);
            entity.Property(e => e.FacebookLink)
                .HasMaxLength(500)
                .HasColumnName("facebookLink");
            entity.Property(e => e.InstagramLink)
                .HasMaxLength(500)
                .HasColumnName("instagramLink");
            entity.Property(e => e.LinkedInLink).HasMaxLength(500);
            entity.Property(e => e.Phone)
                .HasMaxLength(50)
                .HasColumnName("phone");
            entity.Property(e => e.Place)
                .HasMaxLength(50)
                .HasColumnName("place");
            entity.Property(e => e.TwitterLink)
                .HasMaxLength(500)
                .HasColumnName("twitterLink");
            entity.Property(e => e.Vision).HasColumnName("vision");
            entity.Property(e => e.WhatsappLink).HasMaxLength(500);
        });

        modelBuilder.Entity<Subscription>(entity =>
        {
            entity.Property(e => e.Coupon).HasMaxLength(500);
            entity.Property(e => e.Discount).HasColumnName("discount");
            entity.Property(e => e.DiscountRate).HasColumnName("discountRate");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.IsSubscribed).HasColumnName("isSubscribed");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.ProcessNo).HasMaxLength(250);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.State)
                .HasMaxLength(500)
                .HasColumnName("state");
            entity.Property(e => e.SubType).HasMaxLength(15);

            entity.HasOne(d => d.Course).WithMany(p => p.Subscriptions)
                .HasForeignKey(d => d.CourseId)
                .HasConstraintName("FK_Subscriptions_Courses");

            entity.HasOne(d => d.Pack).WithMany(p => p.Subscriptions)
                .HasForeignKey(d => d.PackId)
                .HasConstraintName("FK_Subscriptions_Packages");

            entity.HasOne(d => d.User).WithMany(p => p.Subscriptions)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_Subscriptions_SystemUsers");
        });

        modelBuilder.Entity<SystemUser>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_SystemUsersTable");

            entity.Property(e => e.AccountNo).HasMaxLength(50);
            entity.Property(e => e.AccountType).HasMaxLength(20);
            entity.Property(e => e.AddUser).HasMaxLength(450);
            entity.Property(e => e.AspId)
                .HasMaxLength(450)
                .HasColumnName("ASP_Id");
            entity.Property(e => e.BirthDate).HasColumnType("datetime");
            entity.Property(e => e.BusinessNo).HasMaxLength(450);
            entity.Property(e => e.CashBack).HasColumnName("cashBack");
            entity.Property(e => e.ContractDate).HasColumnName("contractDate");
            entity.Property(e => e.ContractNo).HasMaxLength(1500);
            entity.Property(e => e.DateofJoin).HasColumnType("datetime");
            entity.Property(e => e.Deleted).HasDefaultValue(false);
            entity.Property(e => e.DiscountCode)
                .HasMaxLength(10)
                .IsFixedLength();
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.EnterPrisePhoneNo).HasMaxLength(450);
            entity.Property(e => e.Gender).HasMaxLength(20);
            entity.Property(e => e.IdentityNo).HasMaxLength(100);
            entity.Property(e => e.Lat).HasMaxLength(50);
            entity.Property(e => e.Lng)
                .HasMaxLength(50)
                .HasColumnName("lng");
            entity.Property(e => e.Location).HasMaxLength(250);
            entity.Property(e => e.Logo).HasMaxLength(450);
            entity.Property(e => e.MasterId)
                .HasMaxLength(450)
                .HasColumnName("masterId");
            entity.Property(e => e.Name).HasMaxLength(500);
            entity.Property(e => e.Orderdate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("orderdate");
            entity.Property(e => e.Orderstate)
                .HasMaxLength(50)
                .HasColumnName("orderstate");
            entity.Property(e => e.OverView).HasMaxLength(1500);
            entity.Property(e => e.PhoneNo).HasMaxLength(50);
            entity.Property(e => e.RegisterProgress).HasMaxLength(50);
            entity.Property(e => e.Status)
                .HasMaxLength(1)
                .IsUnicode(false)
                .HasDefaultValue("A")
                .IsFixedLength();
        });

        modelBuilder.Entity<UserBanksAccount>(entity =>
        {
            entity.Property(e => e.AccountNo).HasColumnName("AccountNO");
            entity.Property(e => e.Actype)
                .HasMaxLength(50)
                .HasColumnName("actype");
            entity.Property(e => e.CreateOn).HasColumnType("datetime");
            entity.Property(e => e.IsAuth).HasColumnName("isAuth");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .HasColumnName("state");
            entity.Property(e => e.Temp1)
                .HasMaxLength(500)
                .HasColumnName("temp1");
            entity.Property(e => e.Temp2)
                .HasMaxLength(500)
                .HasColumnName("temp2");
            entity.Property(e => e.UpdatedOn).HasColumnType("datetime");

            entity.HasOne(d => d.Bank).WithMany(p => p.UserBanksAccounts)
                .HasForeignKey(d => d.BankId)
                .HasConstraintName("FK_UserBanksAccounts_BanksAccount");

            entity.HasOne(d => d.MainAccountNavigation).WithMany(p => p.InverseMainAccountNavigation)
                .HasForeignKey(d => d.MainAccount)
                .HasConstraintName("FK_UserBanksAccounts_UserMainBanksAccounts");

            entity.HasOne(d => d.User).WithMany(p => p.UserBanksAccounts)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_UserBanksAccounts_SystemUsers");
        });

        modelBuilder.Entity<UserPointsPartenr>(entity =>
        {
            entity.Property(e => e.ConectDate).HasColumnType("datetime");
            entity.Property(e => e.ConnectState)
                .HasMaxLength(10)
                .IsFixedLength();

            entity.HasOne(d => d.Partner).WithMany(p => p.UserPointsPartenrs)
                .HasForeignKey(d => d.PartnerId)
                .HasConstraintName("FK_UserPointsPartenrs_PointsPartners_PartenerId");

            entity.HasOne(d => d.User).WithMany(p => p.UserPointsPartenrs).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<UserPointsTransction>(entity =>
        {
            entity.ToTable("UserPointsTransction");

            entity.Property(e => e.CreateOn).HasColumnType("datetime");
            entity.Property(e => e.OpType).HasMaxLength(50);
            entity.Property(e => e.Upid).HasColumnName("UPId");

            entity.HasOne(d => d.Partner).WithMany(p => p.UserPointsTransctions)
                .HasForeignKey(d => d.PartnerId)
                .HasConstraintName("FK_UserPointsTransction_UserPointsPartenrs_PartenerId");

            entity.HasOne(d => d.Up).WithMany(p => p.UserPointsTransctions)
                .HasForeignKey(d => d.Upid)
                .HasConstraintName("FK_UserPointsTransction_UserPointsTransction_UPId");

            entity.HasOne(d => d.User).WithMany(p => p.UserPointsTransctions).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<Walet>(entity =>
        {
            entity.ToTable("Walet");

            entity.HasOne(d => d.User).WithMany(p => p.Walets)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_Walet_SystemUsers");
        });

        modelBuilder.Entity<WaletTransction>(entity =>
        {
            entity.Property(e => e.Note).HasMaxLength(500);
            entity.Property(e => e.Optype)
                .HasMaxLength(50)
                .HasColumnName("OPType");
            entity.Property(e => e.OutAmount).HasColumnName("outAmount");

            entity.HasOne(d => d.DistUserNavigation).WithMany(p => p.WaletTransctionDistUserNavigations)
                .HasForeignKey(d => d.DistUser)
                .HasConstraintName("FK_WaletTransctions_SystemUsersDist");

            entity.HasOne(d => d.User).WithMany(p => p.WaletTransctionUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_WaletTransctions_SystemUsers");

            entity.HasOne(d => d.Walet).WithMany(p => p.WaletTransctions)
                .HasForeignKey(d => d.WaletId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_WaletTransctions_Walet");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
