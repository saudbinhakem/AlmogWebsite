﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class CourseCoupon
{
    public int Id { get; set; }

    public int? CourseId { get; set; }

    public string? CouponCode { get; set; }

    public double? Discount { get; set; }

    public DateTime? Datetime { get; set; }

    public virtual Course? Course { get; set; }
}
