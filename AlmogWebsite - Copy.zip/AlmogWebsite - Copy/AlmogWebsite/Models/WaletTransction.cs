﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class WaletTransction
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public double? OutAmount { get; set; }

    public double? InAmount { get; set; }

    public long? DistUser { get; set; }

    public string? Optype { get; set; }

    public string? Note { get; set; }

    public long WaletId { get; set; }

    public virtual SystemUser? DistUserNavigation { get; set; }

    public virtual SystemUser? User { get; set; }

    public virtual Walet Walet { get; set; } = null!;
}
