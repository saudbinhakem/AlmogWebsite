﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class PointsPartner
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? Icon { get; set; }

    public string? EnName { get; set; }

    public string? Overview { get; set; }

    public string? EnOverview { get; set; }

    public string? StoreLink { get; set; }

    public string? Lng { get; set; }

    public string? Lat { get; set; }

    public string? BnifitfmPoints { get; set; }

    public string? EnBnifitfmPoints { get; set; }

    public virtual ICollection<UserPointsPartenr> UserPointsPartenrs { get; set; } = new List<UserPointsPartenr>();

    public virtual ICollection<UserPointsTransction> UserPointsTransctions { get; set; } = new List<UserPointsTransction>();
}
