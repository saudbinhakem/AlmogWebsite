﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class SystemUser
{
    public long Id { get; set; }

    public string? Name { get; set; }

    public int? Nationality { get; set; }

    public string? IdentityNo { get; set; }

    public int? City { get; set; }

    public int? Activity { get; set; }

    public string? ServiceProviderRepresent { get; set; }

    public DateTime? BirthDate { get; set; }

    public string? PhoneNo { get; set; }

    public string? Email { get; set; }

    public string? DiscountCode { get; set; }

    public double? Discount { get; set; }

    public double? Precentage { get; set; }

    public double? Salary { get; set; }

    public string? BusinessNo { get; set; }

    public string? EnterPrisePhoneNo { get; set; }

    public string? Location { get; set; }

    public string? Logo { get; set; }

    public DateTime? DateofJoin { get; set; }

    public string? AddUser { get; set; }

    public string AspId { get; set; } = null!;

    public string? MasterId { get; set; }

    public string? AccountNo { get; set; }

    public double? Amount { get; set; }

    public string? Status { get; set; }

    public string? AccountType { get; set; }

    public bool? IsOrder { get; set; }

    public DateOnly? ContractDate { get; set; }

    public DateOnly? ContractEndDate { get; set; }

    public double? CashBack { get; set; }

    public bool? Deleted { get; set; }

    public string? Orderstate { get; set; }

    public DateTime Orderdate { get; set; }

    public string? Gender { get; set; }

    public string? OverView { get; set; }

    public string? ContractNo { get; set; }

    public string? Lat { get; set; }

    public string? Lng { get; set; }

    public string? RegisterProgress { get; set; }

    public virtual ICollection<ConnectBanksOtpCode> ConnectBanksOtpCodes { get; set; } = new List<ConnectBanksOtpCode>();

    public virtual ICollection<CourseComment> CourseComments { get; set; } = new List<CourseComment>();

    public virtual ICollection<CourseLike> CourseLikes { get; set; } = new List<CourseLike>();

    public virtual ICollection<DiscountsTable> DiscountsTableMasters { get; set; } = new List<DiscountsTable>();

    public virtual ICollection<DiscountsTable> DiscountsTableUsers { get; set; } = new List<DiscountsTable>();

    public virtual ICollection<GrantedDiscount> GrantedDiscountProviders { get; set; } = new List<GrantedDiscount>();

    public virtual ICollection<GrantedDiscount> GrantedDiscountUsers { get; set; } = new List<GrantedDiscount>();

    public virtual ICollection<InvestmentPortfolioTransaction> InvestmentPortfolioTransactions { get; set; } = new List<InvestmentPortfolioTransaction>();

    public virtual ICollection<InvestmentPortfolio> InvestmentPortfolios { get; set; } = new List<InvestmentPortfolio>();

    public virtual ICollection<Otplogin> Otplogins { get; set; } = new List<Otplogin>();

    public virtual ICollection<PointReplaceOrder> PointReplaceOrderProviders { get; set; } = new List<PointReplaceOrder>();

    public virtual ICollection<PointReplaceOrder> PointReplaceOrderUsers { get; set; } = new List<PointReplaceOrder>();

    public virtual ICollection<PointsTable> PointsTables { get; set; } = new List<PointsTable>();

    public virtual ICollection<Subscription> Subscriptions { get; set; } = new List<Subscription>();

    public virtual ICollection<UserBanksAccount> UserBanksAccounts { get; set; } = new List<UserBanksAccount>();

    public virtual ICollection<UserPointsPartenr> UserPointsPartenrs { get; set; } = new List<UserPointsPartenr>();

    public virtual ICollection<UserPointsTransction> UserPointsTransctions { get; set; } = new List<UserPointsTransction>();

    public virtual ICollection<WaletTransction> WaletTransctionDistUserNavigations { get; set; } = new List<WaletTransction>();

    public virtual ICollection<WaletTransction> WaletTransctionUsers { get; set; } = new List<WaletTransction>();

    public virtual ICollection<Walet> Walets { get; set; } = new List<Walet>();
}
