﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class UserBanksAccount
{
    public long Id { get; set; }

    public long? AccountNo { get; set; }

    public string? Name { get; set; }

    public long? UserId { get; set; }

    public string? State { get; set; }

    public bool Deleted { get; set; }

    public long? MainAccount { get; set; }

    public DateTime? CreateOn { get; set; }

    public DateTime? UpdatedOn { get; set; }

    public double? Balance { get; set; }

    public string? Temp1 { get; set; }

    public string? Temp2 { get; set; }

    public bool? Active { get; set; }

    public bool? IsAuth { get; set; }

    public int? BankId { get; set; }

    public string? Actype { get; set; }

    public virtual BanksAccount? Bank { get; set; }

    public virtual ICollection<UserBanksAccount> InverseMainAccountNavigation { get; set; } = new List<UserBanksAccount>();

    public virtual UserBanksAccount? MainAccountNavigation { get; set; }

    public virtual SystemUser? User { get; set; }
}
