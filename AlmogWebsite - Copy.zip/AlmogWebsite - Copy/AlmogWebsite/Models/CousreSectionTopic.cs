﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class CousreSectionTopic
{
    public long Id { get; set; }

    public string? Topic { get; set; }

    public int? CourseId { get; set; }

    public int? SectionId { get; set; }

    public virtual Course? Course { get; set; }

    public virtual CourseSection? Section { get; set; }
}
