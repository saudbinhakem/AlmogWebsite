﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class ArticlesImage
{
    public int Id { get; set; }

    public int ArtId { get; set; }

    public string? Link { get; set; }

    public string? Name { get; set; }

    public string? State { get; set; }

    public bool Deleted { get; set; }

    public virtual Article Art { get; set; } = null!;
}
