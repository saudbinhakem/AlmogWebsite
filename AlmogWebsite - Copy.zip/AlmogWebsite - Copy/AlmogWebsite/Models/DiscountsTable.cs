﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class DiscountsTable
{
    public long Id { get; set; }

    public string? DisCountName { get; set; }

    public double? Discount { get; set; }

    public string? Conditions { get; set; }

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }

    public double? CashBack { get; set; }

    public long? UserId { get; set; }

    public bool? Deleted { get; set; }

    public bool? IsActive { get; set; }

    public string? Orderstate { get; set; }

    public bool? IsOrder { get; set; }

    public DateTime Orderdate { get; set; }

    public long? MasterId { get; set; }

    public bool GrantPoints { get; set; }

    public bool GrantDiscount { get; set; }

    public string? GrantType { get; set; }

    public string? DiscImg { get; set; }

    public string? DiscountCode { get; set; }

    public virtual ICollection<GrantedDiscount> GrantedDiscounts { get; set; } = new List<GrantedDiscount>();

    public virtual SystemUser? Master { get; set; }

    public virtual ICollection<PointsTable> PointsTables { get; set; } = new List<PointsTable>();

    public virtual SystemUser? User { get; set; }
}
