﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class CourseSection
{
    public int Id { get; set; }

    public string? SectionName { get; set; }

    public string? SectionContent { get; set; }

    public DateTime? Datetime { get; set; }

    public string? VideoLink { get; set; }

    public virtual ICollection<CourseSectionTopic> CourseSectionTopics { get; set; } = new List<CourseSectionTopic>();
}
