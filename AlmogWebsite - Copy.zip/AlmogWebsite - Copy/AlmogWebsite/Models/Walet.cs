﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class Walet
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public double? Amount { get; set; }

    public virtual SystemUser? User { get; set; }

    public virtual ICollection<WaletTransction> WaletTransctions { get; set; } = new List<WaletTransction>();
}
