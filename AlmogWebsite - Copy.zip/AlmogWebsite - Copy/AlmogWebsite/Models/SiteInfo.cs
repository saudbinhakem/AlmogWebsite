﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class SiteInfo
{
    public int Id { get; set; }

    public string? Vision { get; set; }

    public string? Defnition { get; set; }

    public string? WorkTime { get; set; }

    public string? Phone { get; set; }

    public string? Email { get; set; }

    public string? Place { get; set; }

    public string? Experts { get; set; }

    public string? Customers { get; set; }

    public string? FacebookLink { get; set; }

    public string? InstagramLink { get; set; }

    public string? TwitterLink { get; set; }

    public string? LinkedInLink { get; set; }

    public string? WhatsappLink { get; set; }

    public string? PrivacyPolicy { get; set; }

    public string? TermsOfUse { get; set; }

    public string? AppLinkApple { get; set; }

    public string? AppLinkGoogle { get; set; }

    public string? Envision { get; set; }

    public string? EnDefnition { get; set; }

    public string? EnPlace { get; set; }

    public string? EnWorkTime { get; set; }
}
