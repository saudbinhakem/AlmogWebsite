﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class PointsTable
{
    public long Id { get; set; }

    public double? PointCount { get; set; }

    public double? Sales { get; set; }

    public double? PointDesrve { get; set; }

    public double? Prize { get; set; }

    public string? Conditions { get; set; }

    public long? UserId { get; set; }

    public long? DiscountId { get; set; }

    public bool? Deleted { get; set; }

    public virtual DiscountsTable? Discount { get; set; }

    public virtual SystemUser? User { get; set; }
}
