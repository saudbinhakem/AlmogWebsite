﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class InvestmentPortfolio
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public string Name { get; set; } = null!;

    public DateTime? ConectDate { get; set; }

    public DateTime? DisconectDate { get; set; }

    public long? AccountId { get; set; }

    public string? Status { get; set; }

    public string? Note { get; set; }

    public virtual ICollection<InvestmentPortfolioAccount> InvestmentPortfolioAccounts { get; set; } = new List<InvestmentPortfolioAccount>();

    public virtual ICollection<InvestmentPortfolioTransaction> InvestmentPortfolioTransactions { get; set; } = new List<InvestmentPortfolioTransaction>();

    public virtual SystemUser? User { get; set; }
}
