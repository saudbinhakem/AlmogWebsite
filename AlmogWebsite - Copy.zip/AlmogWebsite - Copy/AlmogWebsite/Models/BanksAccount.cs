﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class BanksAccount
{
    public int Id { get; set; }

    public string? BankName { get; set; }

    public string? ConnectionCode { get; set; }

    public string? AccountNumber { get; set; }

    public string Target { get; set; } = null!;

    public string? Icon { get; set; }

    public DateTime? CreateOn { get; set; }

    public string State { get; set; } = null!;

    public bool Active { get; set; }

    public bool Deleted { get; set; }

    public string? OperationDetils { get; set; }

    public string? EnBankName { get; set; }

    public virtual ICollection<ConnectBanksOtpCode> ConnectBanksOtpCodes { get; set; } = new List<ConnectBanksOtpCode>();

    public virtual ICollection<UserBanksAccount> UserBanksAccounts { get; set; } = new List<UserBanksAccount>();
}
