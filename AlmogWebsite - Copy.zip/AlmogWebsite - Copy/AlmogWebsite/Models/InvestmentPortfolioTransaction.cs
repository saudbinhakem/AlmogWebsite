﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class InvestmentPortfolioTransaction
{
    public decimal Id { get; set; }

    public long? Ipid { get; set; }

    public long? AccountId { get; set; }

    public double? Deduction { get; set; }

    public DateTime? OperationDate { get; set; }

    public long? UserId { get; set; }

    public string? Temp1 { get; set; }

    public string? Temp2 { get; set; }

    public virtual InvestmentPortfolioAccount? Account { get; set; }

    public virtual InvestmentPortfolio? Ip { get; set; }

    public virtual SystemUser? User { get; set; }
}
