﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class OffersAndCopun
{
    public long Id { get; set; }

    public string? Name { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public string? Details { get; set; }

    public string? StoreLink { get; set; }

    public bool? IsActive { get; set; }

    public string? Img { get; set; }

    public long? MasterId { get; set; }

    public bool Deleted { get; set; }

    public string? RecType { get; set; }

    public string? OverView { get; set; }

    public string? CopunCode { get; set; }

    public double? Discount { get; set; }

    public int? Activity { get; set; }
}
