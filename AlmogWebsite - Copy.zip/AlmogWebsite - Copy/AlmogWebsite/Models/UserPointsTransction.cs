﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class UserPointsTransction
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public int? PartnerId { get; set; }

    public int? Upid { get; set; }

    public string? OpType { get; set; }

    public int? PointsCount { get; set; }

    public DateTime? CreateOn { get; set; }

    public virtual PointsPartner? Partner { get; set; }

    public virtual UserPointsPartenr? Up { get; set; }

    public virtual SystemUser? User { get; set; }
}
