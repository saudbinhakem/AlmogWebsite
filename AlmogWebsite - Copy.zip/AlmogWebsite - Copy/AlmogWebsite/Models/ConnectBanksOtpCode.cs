﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class ConnectBanksOtpCode
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public int? BankId { get; set; }

    public long? OtpId { get; set; }

    public bool IsAuth { get; set; }

    public DateTime? CreateDate { get; set; }

    public virtual BanksAccount? Bank { get; set; }

    public virtual Otplogin? Otp { get; set; }

    public virtual SystemUser? User { get; set; }
}
