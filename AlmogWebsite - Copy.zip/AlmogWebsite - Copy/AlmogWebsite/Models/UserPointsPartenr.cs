﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class UserPointsPartenr
{
    public int Id { get; set; }

    public long? UserId { get; set; }

    public int? PointsCount { get; set; }

    public long? AccountId { get; set; }

    public int? BankId { get; set; }

    public int? PartnerId { get; set; }

    public DateTime? ConectDate { get; set; }

    public string? ConnectState { get; set; }

    public bool Deleted { get; set; }

    public virtual PointsPartner? Partner { get; set; }

    public virtual SystemUser? User { get; set; }

    public virtual ICollection<UserPointsTransction> UserPointsTransctions { get; set; } = new List<UserPointsTransction>();
}
