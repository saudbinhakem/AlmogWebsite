﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class CourseLike
{
    public long Id { get; set; }

    public int? Stars { get; set; }

    public long? UserId { get; set; }

    public int? CourseId { get; set; }

    public bool? Deleted { get; set; }

    public string? Temp1 { get; set; }

    public string? Temp2 { get; set; }

    public virtual Course? Course { get; set; }

    public virtual SystemUser? User { get; set; }
}
