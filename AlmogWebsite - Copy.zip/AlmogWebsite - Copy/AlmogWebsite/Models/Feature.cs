﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class Feature
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? Icon { get; set; }

    public bool? Active { get; set; }

    public string? EnName { get; set; }
}
