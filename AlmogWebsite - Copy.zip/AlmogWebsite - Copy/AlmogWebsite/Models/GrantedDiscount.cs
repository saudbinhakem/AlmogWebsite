﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class GrantedDiscount
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public long? ProviderId { get; set; }

    public long? ProductId { get; set; }

    public double? Amount { get; set; }

    public double? Rate { get; set; }

    public double? Discount { get; set; }

    public DateTime? GrantDate { get; set; }

    public int? Points { get; set; }

    public bool Replaced { get; set; }

    public string OrderState { get; set; } = null!;

    public virtual ICollection<OrderedGrantedDiscount> OrderedGrantedDiscounts { get; set; } = new List<OrderedGrantedDiscount>();

    public virtual DiscountsTable? Product { get; set; }

    public virtual SystemUser? Provider { get; set; }

    public virtual SystemUser? User { get; set; }
}
