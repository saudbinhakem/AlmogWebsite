﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class BankAccountTransction
{
    public long Id { get; set; }

    public long? AccId { get; set; }

    public DateTime? DateOfOp { get; set; }

    public double? Amount { get; set; }

    public string? OpType { get; set; }

    public string? Note { get; set; }

    public long? UserId { get; set; }

    public long? DistAccId { get; set; }

    public long? DistUserId { get; set; }

    public string? Purpose { get; set; }

    public string? State { get; set; }

    public string? DistAccNo { get; set; }

    public string? Temp1 { get; set; }

    public string? Temp2 { get; set; }
}
