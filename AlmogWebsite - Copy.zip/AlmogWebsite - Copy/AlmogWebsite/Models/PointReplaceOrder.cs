﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class PointReplaceOrder
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public long? ProviderId { get; set; }

    public double? PointCount { get; set; }

    public string? AgentName { get; set; }

    public double? DesrveAmount { get; set; }

    public bool? Accept { get; set; }

    public string State { get; set; } = null!;

    public DateTime OrderDate { get; set; }

    public virtual ICollection<OrderedGrantedDiscount> OrderedGrantedDiscounts { get; set; } = new List<OrderedGrantedDiscount>();

    public virtual SystemUser? Provider { get; set; }

    public virtual SystemUser? User { get; set; }
}
