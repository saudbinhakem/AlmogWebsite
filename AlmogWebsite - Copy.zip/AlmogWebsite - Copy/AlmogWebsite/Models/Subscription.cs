﻿using System;
using System.Collections.Generic;

namespace AlmogWebsite.Models;

public partial class Subscription
{
    public long Id { get; set; }

    public long? UserId { get; set; }

    public int? PackId { get; set; }

    public int? CourseId { get; set; }

    public string? SubType { get; set; }

    public bool? IsSubscribed { get; set; }

    public string? State { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public double? Price { get; set; }

    public double? Discount { get; set; }

    public double? DiscountRate { get; set; }

    public string? Coupon { get; set; }

    public string? ProcessNo { get; set; }

    public virtual Course? Course { get; set; }

    public virtual Package? Pack { get; set; }

    public virtual SystemUser? User { get; set; }
}
