﻿using System.Net;
using System.Net.Mail;

namespace App.Helpers
{
    public class MailClass
    {
        public void Send(App.Entity.MailModel mail)
        {
            Task savetask = Task.Run(() => sendImail(mail));
        }
        private async Task<bool> sendImail(App.Entity.MailModel mail) {
            try
            {
                string fromMail = "bssam09azab@gmail.com";
                string fromPassword = /*info.password;*/"tzhdcrzlkxncznor";
                MailMessage message = new MailMessage();
                message.From = new MailAddress(fromMail);
                message.Subject = mail.Subject;
                message.To.Add(new MailAddress(mail.Email));
                message.Body = mail.body;
                message.IsBodyHtml = true;
                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential(fromMail, fromPassword),
                    EnableSsl = true,
                };
                smtpClient.Send(message);
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
