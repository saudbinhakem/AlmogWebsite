﻿using AlmogWebsite.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class subscribersController : Controller
    {
        private readonly ILogger<subscribersController> _logger;
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<subscribersController> _localization;
        public subscribersController(ILogger<subscribersController> logger, IStringLocalizer<subscribersController> _localization, AlmogdatabaseContext context)
        {
            _logger = logger;
            _context = context;
            this._localization = _localization;
        }
        // GET: subscribersController
        public ActionResult Index()
        {
            var list = _context.SystemUsers.Where(o => o.AccountType == "customer").
                Select( e =>new App.Entity.subscribers
                {Email=e.Email, Name=e.Name,
                phone=e.PhoneNo,
                amount=_context.Subscriptions.Where(r=>r.UserId==e.Id&&r.SubType=="c").Sum(p=>p.Price),
                courses= _context.Subscriptions.Where(r => r.UserId == e.Id && r.SubType == "c").Count(),
                Id=e.Id


                }).ToList(); 
            return View(list);
        }

        // GET: subscribersController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: subscribersController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: subscribersController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: subscribersController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: subscribersController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: subscribersController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: subscribersController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
