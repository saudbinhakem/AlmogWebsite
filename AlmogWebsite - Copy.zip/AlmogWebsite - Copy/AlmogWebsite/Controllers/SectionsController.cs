﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AlmogWebsite.Models;
using App.Entity;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class SectionsController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<SectionsController> _localization;
        public SectionsController(AlmogdatabaseContext context, IStringLocalizer<SectionsController> _localization)
        {
            _context = context;
            this._localization = _localization;
        }

        // GET: Sections
        public async Task<IActionResult> Index()
        {
            return View(await _context.CourseSections.ToListAsync());
        }

        // GET: Sections/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseSection = await _context.CourseSections
                .FirstOrDefaultAsync(m => m.Id == id);
            if (courseSection == null)
            {
                return NotFound();
            }

            return View(courseSection);
        }

        // GET: Sections/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Sections/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,SectionName,SectionContent,Datetime,VideoLink")] CourseSection courseSection)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    courseSection.Datetime  = DateTime.Now;
                    _context.Add(courseSection);
                    await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Sections/Index" });
                }
                else
                    return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message = _localization["errorwillsaving"].Value });
            }
        }

        // GET: Sections/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseSection = await _context.CourseSections.FindAsync(id);
            if (courseSection == null)
            {
                return NotFound();
            }
            return View(courseSection);
        }

        // POST: Sections/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,SectionName,SectionContent,Datetime,VideoLink")] CourseSection courseSection)
        {
            var course = await _context.CourseSections.FindAsync(courseSection.Id);
            if (course == null) return Ok(new Response { state = 0, message = _localization["sectionnotfound"].Value });
            if (ModelState.IsValid)
            {
                try
                {
                    course.SectionName = courseSection.SectionName;
                    _context.Update(course);
                    await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["modefiedsuccessfuly"].Value, url = "/Sections/Index" });
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Ok(new Response { state = 0, message = _localization["errorinoperation"].Value });
                }
            }
            return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
        }

        // GET: Sections/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseSection = await _context.CourseSections
                .FirstOrDefaultAsync(m => m.Id == id);
            if (courseSection == null)
            {
                return NotFound();
            }

            return View(courseSection);
        }

        // POST: Sections/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            
            try
            {
                var courseSection = await _context.CourseSections.FindAsync(id);
                if (courseSection != null)
                {
                    _context.CourseSections.Remove(courseSection);
                }
                else
                    return Ok(new Response { state = 0, message =  _localization["coursenotfound"].Value });

                await _context.SaveChangesAsync();
                return Ok(new Response { state = 2, message = _localization["deletessuccessfuly"].Value , url = "/Sections/Index" });
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message =  _localization["errorinoperation"].Value});
                }
        }

        private bool CourseSectionExists(int id)
        {
            return _context.CourseSections.Any(e => e.Id == id);
        }
    }
}
