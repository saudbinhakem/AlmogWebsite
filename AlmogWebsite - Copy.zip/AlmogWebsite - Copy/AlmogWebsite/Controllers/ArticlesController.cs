﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AlmogWebsite.Models;
using App.Entity;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class ArticlesController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IWebHostEnvironment _hosting;
        private readonly IStringLocalizer<ArticlesController> _localization;
        public ArticlesController(AlmogdatabaseContext context, IStringLocalizer<ArticlesController> _localization, IWebHostEnvironment _hosting)
        {
            _context = context;
            this._hosting = _hosting;
            this._localization = _localization;
        }

        // GET: Articles
        public async Task<IActionResult> Index()
        {
            var temp = await _context.Articles.Where(e => e.Deleted == false && e.Catgory == "art").ToListAsync();
            return View(temp);
        }

        // GET: Articles/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var article = await _context.Articles
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }
            var temp = new App.Entity.ArticleUpdateModel() {
                Id = article.Id,
                Title = article.Title,
                Body = article.Body,
                Lang = article.Lang,
                OverView = article.OverView,
                WriteDate = article.WriteDate.ToString(),
                imgUrls = _context.ArticlesImages.Where(e => e.ArtId == article.Id).Select(o => new App.Entity.ImagesModel { imgId = o.Id, imgUrl ="/img/"+ o.Link }).ToList()
            };
            return View(temp);
        }

        // GET: Articles/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Articles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(App.Entity.ArticlePostModel article)
        {
            if (ModelState.IsValid)
            {
                var x = new List<string>();
                try
                {
                    _context.Database.BeginTransaction();
                    var temp = new Models.Article()
                    {
                        OverView = article.OverView,
                        WriteDate = DateTime.Now,
                        Body = article.Body,
                        Title = article.Title,
                        Lang=article.Lang,
                        Catgory="art"
                    };
                    _context.Add(temp);
                    await _context.SaveChangesAsync();
                    if (article.img != null)
                    {
                        foreach (var item in article.img)
                        {
                            var img = new Models.ArticlesImage();

                            img.ArtId = temp.Id;
                            img.Link = App.Helpers.HandleImages.SaveImage(item, "img", _hosting);
                            _context.Add(img);
                            x.Add(img.Link);
                        }
                        await _context.SaveChangesAsync();
                        
                    }
                    _context.Database.CommitTransaction();
                    return Ok(new Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Articles/Index" });
                }
                catch (Exception)
                {
                    _context.Database.RollbackTransaction();
                    if (x != null) { foreach (var item in x) App.Helpers.HandleImages.RemoveImage(item, "img", _hosting); }
                    return Ok(new Response { state = 0, message = _localization["errorwillsaving"].Value });
                }
            }
            return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
        }

        // GET: Articles/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var article = await _context.Articles.FindAsync(id);
            if (article == null)
            {
                return NotFound();
            }
            var temp = new App.Entity.ArticleUpdateModel()
            {
                Id = article.Id,
                Title = article.Title,
                Body = article.Body,
                Lang = article.Lang,    
                OverView = article.OverView,
                WriteDate = article.WriteDate.ToString(),
                imgUrls = _context.ArticlesImages.Where(e => e.ArtId == article.Id).Select(o => new App.Entity.ImagesModel { imgId = o.Id, imgUrl ="/img/"+ o.Link }).ToList()
            };
            return View(temp);
        }

        // POST: Articles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit( App.Entity.ArticleUpdateModel article)
        {
            var ob = await _context.Articles.FindAsync(article.Id);
            if (ob == null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                var x = new List<string>();
                try
                {
                    _context.Database.BeginTransaction();
                    ob.OverView = article.OverView;
                    ob.Title = article.Title;
                    ob.Body = article.Body;
                    ob.Lang = article.Lang;
                    _context.Update(ob);
                    if (article.img != null)
                    {
                        foreach(var item in article.img)
                        {
                            var img = new Models.ArticlesImage();

                            img.ArtId = ob.Id;

                            img.Link=App.Helpers.HandleImages.SaveImage(item, "img", _hosting);
                            _context.Add(img);
                            x.Add(img.Link);
                        }                      
                    }
                    await _context.SaveChangesAsync();
                    _context.Database.CommitTransaction();
                    return Ok(new Response { state = 2, message = _localization["modefiedsuccessfuly"].Value, url = "/Articles/Index" });
                }
                catch (Exception ex)
                {
                    _context.Database.RollbackTransaction();
                    if (x != null) { foreach (var item in x) App.Helpers.HandleImages.RemoveImage(item, "img", _hosting); }
                    return Ok(new Response { state = 0, message = _localization["errorwillsditing"].Value });
                }
              
            }
            return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
        }

        // GET: Articles/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var article = await _context.Articles
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }
            var temp = new App.Entity.ArticleUpdateModel()
            {
                Id = article.Id,
                Title = article.Title,
                Body = article.Body,
                OverView = article.OverView,
                WriteDate = article.WriteDate.ToString(),
                imgUrls = _context.ArticlesImages.Where(e => e.ArtId == article.Id).Select(o => new App.Entity.ImagesModel { imgId = o.Id, imgUrl ="/img/"+ o.Link }).ToList()
            };
            return View(temp);
        }

        // POST: Articles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {        
            var article = await _context.Articles.FindAsync(id);
            if (article != null)
            {
                var temp = _context.ArticlesImages.Where(e => e.ArtId == article.Id).Select(o => o.Link).ToList();
                try
                {
                    _context.Database.BeginTransaction();
                    _context.ArticlesImages.RemoveRange(article.ArticlesImages.ToList());
                    _context.Articles.Remove(article);
                    await _context.SaveChangesAsync();
                    _context.Database.CommitTransaction();
                    return Ok(new Response { state = 2, message = _localization["modefiedsuccessfuly"].Value, url = "/Articles/Index" });
                }
                catch (Exception)
                {
                    _context.Database.RollbackTransaction();
                    if (temp != null) { foreach (var item in temp) App.Helpers.HandleImages.RemoveImage(item, "img", _hosting); }
                     return Ok(new Response { state = 0, message = _localization["errorwillsdeleting"].Value });
                }
            }
           else
           {
                    return Ok(new Response { state = 0, message = _localization["articlenotfount"].Value });
           }
            
           

            
            
        }

        private bool ArticleExists(int id)
        {
            return _context.Articles.Any(e => e.Id == id);
        }
    }
}
