﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AlmogWebsite.Models;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class CourseSectionTopicsController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IWebHostEnvironment _hosting;
        private readonly IStringLocalizer<CourseSectionTopicsController> _localization;
        public CourseSectionTopicsController(AlmogdatabaseContext context, IStringLocalizer<CourseSectionTopicsController> _localization, IWebHostEnvironment _hosting)
        {
            _context = context;
            this._localization = _localization;
            this._hosting = _hosting;
        }

        // GET: CourseSectionTopics
        public async Task<IActionResult> Index(long? id)
        {
            if(id==null) return View(new List<CourseSectionTopic>());
           
            ViewBag.CourseId= id;
            var almogdatabaseContext = _context.CourseSectionTopics.Include(c => c.Section).Include(c => c.Course);
            return View(await almogdatabaseContext.Where(e=>e.CourseId==id).ToListAsync());
        }

        // GET: CourseSectionTopics/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseSectionTopic = await _context.CourseSectionTopics
                .Include(c => c.Course)
                .Include(c => c.Section)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (courseSectionTopic == null)
            {
                return NotFound();
            }
            ViewData["Course"] = courseSectionTopic.Course.Titel;
            ViewData["Section"] = _context.CourseSections.Find(courseSectionTopic.SectionId)?.SectionName;
            return View(new App.Entity.CourseSectionTopic { Link = "/video/" + courseSectionTopic.Link, Topic = courseSectionTopic.Topic, CId = courseSectionTopic.CourseId, CourseId = courseSectionTopic.CourseId, Id = courseSectionTopic.Id });

        }

        // GET: CourseSectionTopics/Create
        public IActionResult Create(int? id)
        {
            //if (id == null) return RedirectToAction("/Courses/Index");
            ViewData["Id"] =id;
            if (id != null) 
            ViewData["Name"] = _context.Courses.Find(id)?.Titel;
            if(id==null)
            ViewData["CourseId"] = new SelectList(_context.Courses, "Id", "Titel");
            else ViewData["CourseId"] = new SelectList(_context.Courses, "Id", "Titel",id);
           
            ViewData["SectionId"] = new SelectList(_context.CourseSections, "Id", "SectionName");
            return View();
        }

        // POST: CourseSectionTopics/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(App.Entity. CourseSectionTopic courseSectionTopic)
        {
            if (ModelState.IsValid)
            {
                string x = "";
                try
                {
                     x = App.Helpers.HandleImages.SaveImage(courseSectionTopic.File, "video", _hosting);
                    var ob = new CourseSectionTopic()
                    {

                        CourseId = (courseSectionTopic.CId!=null)? courseSectionTopic.CId:courseSectionTopic.CourseId,
                        SectionId = courseSectionTopic.SectionId,
                        Topic = courseSectionTopic.Topic,
                        Link = x

                    };
                    _context.Add(ob);
                    await _context.SaveChangesAsync();
                    return Ok(new App.Entity.Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Index/" + courseSectionTopic.CId });

                }
                catch (Exception)
                {

                    if (x != null) { App.Helpers.HandleImages.RemoveImage(x, "video", _hosting); }
                    return Ok(new App.Entity.Response { state = 0, message =_localization["errorwillsaving"].Value});
                }
            }
            ViewData["CourseId"] = new SelectList(_context.Courses, "Id", "Id", courseSectionTopic.CourseId);
            ViewData["SectionId"] = new SelectList(_context.CourseSections, "Id", "Id", courseSectionTopic.SectionId);
            return Ok(new App.Entity.Response { state = 0, message =_localization["validateallparamaters"].Value });
        }

        // GET: CourseSectionTopics/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseSectionTopic = await _context.CourseSectionTopics.FindAsync(id);
            if (courseSectionTopic == null)
            {
                return NotFound();
            }
            ViewData["Course"] = _context.Courses.Find(courseSectionTopic.CourseId)?.Titel;
            //ViewData["CourseId"] = new SelectList(_context.Courses, "Id", "Id", courseSectionTopic.CourseId);
            //ViewData["SectionId"] = new SelectList(_context.CourseSections, "Id", "Id", courseSectionTopic.SectionId);
            ViewData["Section"] =_context.CourseSections.Find(courseSectionTopic.SectionId)?.SectionName;
            return View(new App.Entity.CourseSectionTopicEdit { Link="/video/"+courseSectionTopic.Link,Topic=courseSectionTopic.Topic,CId=courseSectionTopic.CourseId,CourseId=courseSectionTopic.CourseId,Id=courseSectionTopic.Id});
        }

        // POST: CourseSectionTopics/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(App.Entity.CourseSectionTopicEdit courseSectionTopic)
        {
            

            if (ModelState.IsValid)
            {
                
                var temp = await _context.CourseSectionTopics.FindAsync(courseSectionTopic.Id);
                if (temp == null) return Ok(new App.Entity.Response { state = 0, message = _localization["recordnotfound"].Value });
                string oldLink =temp.Link;
                try
                {
                    temp.Link = App.Helpers.HandleImages.SaveImage(courseSectionTopic.File, "video", _hosting);
                   temp.CourseId = courseSectionTopic.CourseId;
                        temp.SectionId = courseSectionTopic.SectionId;
                       temp.Topic = courseSectionTopic.Topic;
                    

                    
                    _context.Update(temp);
                    await _context.SaveChangesAsync();
                    return Ok(new App.Entity.Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Index/" + courseSectionTopic.CId });
                }
                catch (Exception)
                {
                    if(courseSectionTopic.File!=null&& oldLink!=null) App.Helpers.HandleImages.RemoveImage(oldLink, "video", _hosting);

                }
                
            }
            ViewData["CourseId"] = new SelectList(_context.Courses, "Id", "Id", courseSectionTopic.CourseId);
            ViewData["SectionId"] = new SelectList(_context.CourseSections, "Id", "Id", courseSectionTopic.SectionId);
            return Ok(new App.Entity.Response { state = 0, message = _localization["validateallparamaters"].Value });
        }

        // GET: CourseSectionTopics/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var courseSectionTopic = await _context.CourseSectionTopics
                .Include(c => c.Course)
                .Include(c => c.Section)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (courseSectionTopic == null)
            {
                return NotFound();
            }
            ViewData["Course"] = _context.Courses.Find(courseSectionTopic.CourseId)?.Titel;
           
            ViewData["Section"] = _context.CourseSections.Find(courseSectionTopic.SectionId)?.SectionName;
            return View(new App.Entity.CourseSectionTopicEdit { Link = "/video/" + courseSectionTopic.Link, Topic = courseSectionTopic.Topic, CId = courseSectionTopic.CourseId, CourseId = courseSectionTopic.CourseId, Id = courseSectionTopic.Id });

        }

        // POST: CourseSectionTopics/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            try
            {
                var courseSectionTopic = await _context.CourseSectionTopics.FindAsync(id);
                if (courseSectionTopic != null)
                {
                    _context.CourseSectionTopics.Remove(courseSectionTopic);
                }
                var link = courseSectionTopic.Link;
                await _context.SaveChangesAsync();
                App.Helpers.HandleImages.RemoveImage(link, "video", _hosting);
                return Ok(new App.Entity.Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Index/" + courseSectionTopic.CourseId });
            }
            catch (Exception)
            {
                return Ok(new App.Entity.Response { state = 0, message = _localization["errorwillsaving1"].Value });
               
            }
           
        }

        private bool CourseSectionTopicExists(long id)
        {
            return _context.CourseSectionTopics.Any(e => e.Id == id);
        }
    }
}
