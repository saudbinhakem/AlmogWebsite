﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AlmogWebsite.Models;
using App.Entity;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class PointsPartnersController : Controller
    {
        private readonly AlmogdatabaseContext _context;

        private readonly IWebHostEnvironment _hosting;
        private readonly IStringLocalizer<PointsPartnersController> _localization;
        public PointsPartnersController(AlmogdatabaseContext context, IStringLocalizer<PointsPartnersController> _localization,IWebHostEnvironment _hosting)
        {
            _context = context;
            this._hosting = _hosting;
            this._localization = _localization; 
        }

        // GET: PointsPartners
        public async Task<IActionResult> Index()
        {
            return View(await _context.PointsPartners.ToListAsync());
        }

        // GET: PointsPartners/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pointsPartner =  _context.PointsPartners
                .Where(m => m.Id == id).Select(e=> new Models.PointsPartner { Icon="/img/"+e.Icon,
                    Lng = e.Lng,
                    Lat = e.Lat,
                    Name =e.Name,Id=e.Id,EnName=e.EnName, BnifitfmPoints = e.BnifitfmPoints, EnBnifitfmPoints = e.EnBnifitfmPoints, EnOverview = e.EnOverview, Overview = e.Overview, StoreLink = e.StoreLink }).FirstOrDefault();
            if (pointsPartner == null)
            {
                return NotFound();
            }

            return View(pointsPartner);
        }

        // GET: PointsPartners/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PointsPartners/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(App .Entity.PointsPartner pointsPartner)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    pointsPartner.Icon = App.Helpers.HandleImages.SaveImage(pointsPartner.File, "img", _hosting);

                    _context.Add(new Models.PointsPartner() { Icon= pointsPartner.Icon 
                        ,Name=pointsPartner.Name,
                        EnName=pointsPartner.EnName,
                        BnifitfmPoints=pointsPartner.BnifitfmPoints,
                        EnBnifitfmPoints=pointsPartner.EnBnifitfmPoints,
                        EnOverview=pointsPartner.EnOverview,
                        Overview=pointsPartner.Overview,
                        StoreLink=pointsPartner.StoreLink,
                        Lat=pointsPartner.Lat,
                        Lng=pointsPartner.lng
                    });
                    await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/PointsPartners/Index" });
                    
                }
                catch (Exception)
                {
                    if (pointsPartner.Icon != null) {  App.Helpers.HandleImages.RemoveImage(pointsPartner.Icon, "img", _hosting); }
                    //throw;
                    return Ok(new Response { state = 0, message = _localization["errorwillsaving"].Value });
                }
            }
            return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
            //return View(pointsPartner);
        }

        // GET: PointsPartners/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pointsPartner = await _context.PointsPartners.FindAsync(id);
            if (pointsPartner == null)
            {
                return NotFound();
            }
            return View(new App.Entity.PointsPartnerEdit() { Icon="/img/"+pointsPartner.Icon,
                Id=pointsPartner.Id,Name=pointsPartner.Name,EnName=pointsPartner.EnName,
                BnifitfmPoints = pointsPartner.BnifitfmPoints, EnBnifitfmPoints = pointsPartner.EnBnifitfmPoints,
                EnOverview = pointsPartner.EnOverview, 
               lng=pointsPartner.Lng ?? "46.70213857938796",
                Lat=pointsPartner.Lat ?? "24.67592860338076",
                mapName= (pointsPartner.Lat!=null)?pointsPartner.EnName:"Halala Plus",
                Overview = pointsPartner.Overview, StoreLink = pointsPartner.StoreLink });
        }

        // POST: PointsPartners/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, App.Entity. PointsPartnerEdit pointsPartner)
        {
            
            var ob = await _context.PointsPartners.FindAsync(pointsPartner.Id);
            if(ob == null) { return NotFound(); }
            if (ModelState.IsValid)
            {
                string oldicon = ob.Icon;
                try
                {
                    ob.Name=pointsPartner.Name;
                    ob.EnName=pointsPartner.EnName;
                    ob.BnifitfmPoints = pointsPartner.BnifitfmPoints;
                    ob.EnBnifitfmPoints = pointsPartner.EnBnifitfmPoints;
                    ob.EnOverview = pointsPartner.EnOverview;
                    ob.Overview = pointsPartner.Overview;
                    ob.StoreLink = pointsPartner.StoreLink;
                    ob.Lat = pointsPartner.Lat;
                    ob.Lng = pointsPartner.lng;
                  
                    if (pointsPartner.File!=null)
                        ob.Icon = App.Helpers.HandleImages.SaveImage(pointsPartner.File, "img", _hosting);
                    
                    _context.Update(ob);
                    await _context.SaveChangesAsync();
                    if (pointsPartner.File !=null && oldicon!=null) { App.Helpers.HandleImages.RemoveImage(oldicon, "img", _hosting); }
                    return Ok(new Response { state = 2, message = _localization["modefiedsuccessfuly"].Value, url = "/PointsPartners/Index" });
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (pointsPartner.Icon != oldicon) { App.Helpers.HandleImages.RemoveImage(pointsPartner.Icon, "img", _hosting); }
                    return Ok(new Response { state = 0, message = _localization["errorwillsditing"].Value });
                }
              
            }
            return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
        }

        // GET: PointsPartners/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pointsPartner = _context.PointsPartners
               .Where(m => m.Id == id).Select(e => new Models.PointsPartner { Icon = "/img/" + e.Icon, Name = e.Name, 
                   Id = e.Id,EnName=e.EnName, BnifitfmPoints = e.BnifitfmPoints,
                   Lng=e.Lng,
                   Lat=e.Lat,
                   EnBnifitfmPoints = e.EnBnifitfmPoints, EnOverview = e.EnOverview, Overview = e.Overview, StoreLink = e.StoreLink }).FirstOrDefault();

            if (pointsPartner == null)
            {
                return NotFound();
            }

            return View(pointsPartner);
        }

        // POST: PointsPartners/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            
            var pointsPartner = await _context.PointsPartners.FindAsync(id);
            if (pointsPartner == null) return Ok(new Response { state = 0, message = _localization["recordnotfound"].Value });
            string url = pointsPartner.Icon;
            try
            {
                _context.PointsPartners.Remove(pointsPartner);


                await _context.SaveChangesAsync();
                if (url != null) {  App.Helpers.HandleImages.RemoveImage(url, "img", _hosting); }
                return Ok(new Response { state = 2, message = _localization["deletessuccessfuly"].Value, url = "/PointsPartners/Index" });
                
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message = _localization["errorwillsdeleting"].Value });
            }
        }

        private bool PointsPartnerExists(int id)
        {
            return _context.PointsPartners.Any(e => e.Id == id);
        }
    }
}
