﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AlmogWebsite.Models;
using App.Entity;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class PayingCompaniesController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<PayingCompaniesController> _localization;
        public PayingCompaniesController(AlmogdatabaseContext context, IStringLocalizer<PayingCompaniesController> _localization)
        {
            this._localization = _localization;
            _context = context;
        }

        // GET: PayingCompanies
        public async Task<IActionResult> Index()
        {
            //ViewData["message"] = "يجب اختيار رقم الباقة";
            return View(await _context.BanksAccounts.Where(e=>e.Deleted!=true).ToListAsync());
        }

        // GET: PayingCompanies/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var payingCompaniesTable = await _context.BanksAccounts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (payingCompaniesTable == null)
            {
                return NotFound();
            }

            return View(payingCompaniesTable);
        }

        // GET: PayingCompanies/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PayingCompanies/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( App.Entity.BankModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var ob = new BanksAccount() { 
                    
                        ConnectionCode=model.ConnectionCode,
                        BankName=model.BankName,
                        OperationDetils=model.OperationDetils,
                        EnBankName=model.EnBankName,
                        CreateOn=DateTime.Now,
                        
                    };
                    _context.Add(ob);
                    await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Packages/Index" });
                }
                else { return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value }); }
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message = _localization["errorwillsaving1"].Value });
            }
            
        }

        // GET: PayingCompanies/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var payingCompaniesTable = await _context.BanksAccounts.FindAsync(id);
            if (payingCompaniesTable == null)
            {
                return NotFound();
            }
            return View(payingCompaniesTable);
        }

        // POST: PayingCompanies/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit( App.Entity.BankModel model)
        {
            var payingCompaniesTable = await _context.BanksAccounts
                .FirstOrDefaultAsync(m => m.Id == model.Id);
            if ( payingCompaniesTable==null)
            {
                return Ok(new Response { state = 0, message = _localization["errorwillsditing"].Value });
            }

            if (ModelState.IsValid)
            {
                try
                {
                    payingCompaniesTable.ConnectionCode = model.ConnectionCode;
                    payingCompaniesTable.EnBankName = model.EnBankName;
                    payingCompaniesTable.BankName = model.BankName;
                    payingCompaniesTable.OperationDetils = model.OperationDetils;
                    _context.Update(payingCompaniesTable);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Ok(new Response { state = 0, message = _localization["errorwillsditing"].Value });

                    //if (!PayingCompaniesTableExists(payingCompaniesTable.Id))
                    //{
                    //    return NotFound();
                    //}
                    //else
                    //{
                    //    throw;
                    //}

                }
                return Ok(new Response { state = 2, message = _localization["modefiedsuccessfuly"].Value, url = "/payingCompanies/Index" });
               
            }
            return Ok(new Response { state = 0, message = _localization["anerroroccured"].Value });

        }

        // GET: PayingCompanies/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var payingCompaniesTable = await _context.BanksAccounts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (payingCompaniesTable == null)
            {
                return NotFound();
            }

            return View(payingCompaniesTable);
        }

        // POST: PayingCompanies/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var payingCompaniesTable = await _context.BanksAccounts.FindAsync(id);
                if (payingCompaniesTable != null)
                {
                    payingCompaniesTable.Deleted = true;

                    _context.BanksAccounts.Update(payingCompaniesTable);
                }

                await _context.SaveChangesAsync();
                return Ok(new Response { state = 2, message = _localization["deletessuccessfuly"].Value, url = "/payingCompanies/Index" });
            }
            catch (Exception)
            {
                await _context.SaveChangesAsync();
                return Ok(new Response { state = 0, message = _localization["anerroroccured"].Value, url = nameof(Index) });
               
            }
           
        }

        private bool PayingCompaniesTableExists(int id)
        {
            return _context.BanksAccounts.Any(e => e.Id == id);
        }
    }
}
