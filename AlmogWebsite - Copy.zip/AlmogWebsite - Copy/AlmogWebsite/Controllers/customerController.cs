﻿using AlmogWebsite.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class customerController : Controller
    {
        private readonly ILogger<customerController> _logger;
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<customerController> _localization;
        public customerController(ILogger<customerController> logger, IStringLocalizer<customerController> _localization, AlmogdatabaseContext context)
        {
            _logger = logger;
            this._localization = _localization; 
            _context = context;
        }
        // GET: customerController
        public async Task<IActionResult> Index()
        {
            return View(await _context.SystemUsers.Where(e => e.AccountType =="customer").ToListAsync());
           
        }

        // GET: customerController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: customerController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: customerController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: customerController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: customerController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: customerController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: customerController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
