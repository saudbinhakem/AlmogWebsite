﻿using AlmogWebsite.Models;
using App.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class FeaturesController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<FeaturesController> _localization;
        private readonly IWebHostEnvironment _hosting;
        public FeaturesController(AlmogdatabaseContext context, IStringLocalizer<FeaturesController> _localization,IWebHostEnvironment hosting)
        {
            _context = context;
            _hosting = hosting;
        }

        // GET: Articles
        public async Task<IActionResult> Index()
        {
            var temp = _context.Features.Select(e => new App.Entity.Features
            {

                Text = e.Name,
                icon = e.Icon,
                EnName=e.EnName,
                Id = e.Id,
            }).OrderBy(p => p.Id).ToList();
            return View(temp);
        }

        // GET: Articles/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Features == null)
            {
                return NotFound();
            }

            var article = await _context.Features
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }

            return View(article);
        }

        // GET: Articles/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Articles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(App.Entity.Features article)
        {
            if (ModelState.IsValid)
            {
                var temp = new AlmogWebsite.Models.Feature();
                try
                {

                    temp.Name = article.Text;
                    temp.EnName = article.EnName;
                    if (article.File != null) temp.Icon = HandleImages.SaveImage(article.File, "img", _hosting);
                    _context.Add(temp);
                    await _context.SaveChangesAsync();
                }
                catch (Exception)
                {
                    if (article.icon != null) HandleImages.RemoveImage(temp.Icon, "img", _hosting);
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(article);
        }

        // GET: Articles/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Features == null)
            {
                return NotFound();
            }

            var article = await _context.Features.FindAsync(id);
            if (article == null)
            {
                return NotFound();
            }
            var ob = new App.Entity.Features()
            {

                Text = article.Name,
                EnName = article.EnName,
                icon ="/img/"+ article.Icon,
                Id = article.Id,

            };
            return View(ob);
        }

        // POST: Articles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(App.Entity.Features article)
        {

            if (ModelState.IsValid)
            {
                var ob = await _context.Features.FindAsync(article.Id);
                if (ob == null) return View(article);
                string icon = ob.Icon;
                try
                {

                    ob.EnName = article.EnName;
                    ob.Name = article.Text;
                    if (article.File != null)  ob.Icon = HandleImages.SaveImage(article.File, "img", _hosting);
                    _context.Update(ob);
                    await _context.SaveChangesAsync();
                    if (article.File != null && icon != null) HandleImages.RemoveImageRoot(icon, "img", _hosting);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (article.icon != null) HandleImages.RemoveImage(ob.Icon, "img", _hosting);
                    if (!ArticleExists(article.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(article);
        }

        // GET: Articles/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Features == null)
            {
                return NotFound();
            }

            var article = await _context.Features
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }

            return View(article);
        }

        // POST: Articles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Features == null)
            {
                return Problem("Entity set 'AbdLawyerDBContext.Articles'  is null.");
            }
            var article = await _context.Features.FindAsync(id);
            if (article != null)
            {
                _context.Features.Remove(article);
            }

            await _context.SaveChangesAsync();
            if (article.Icon != null) HandleImages.RemoveImage(article.Icon, "img", _hosting);
            return RedirectToAction(nameof(Index));
        }

        private bool ArticleExists(int id)
        {
            return (_context.Features?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
