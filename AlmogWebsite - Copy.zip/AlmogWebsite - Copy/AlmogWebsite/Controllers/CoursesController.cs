﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AlmogWebsite.Models;
using App.Entity;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class CoursesController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<CoursesController> _localization;
        public CoursesController(AlmogdatabaseContext context, IStringLocalizer<CoursesController> _localization)
        {
            _context = context;
            this._localization = _localization;
        }

        // GET: Courses
        public async Task<IActionResult> Index()
        {
            return View(await _context.Courses.ToListAsync());
        }

        // GET: Courses/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Courses
                .FirstOrDefaultAsync(m => m.Id == id);
            if (course == null)
            {
                return NotFound();
            }

            return View(course);
        }

        // GET: Courses/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Courses/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( Course course)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(course);
                    await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Courses/Index" });
                }
                else
                    return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message = _localization["errorwillsaving"].Value });
            }
        }

        // GET: Courses/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Courses.FindAsync(id);
            if (course == null)
            {
                return NotFound();
            }
            return View(course);
        }

        // POST: Courses/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Course model)
        {
            
            var course = await _context.Courses.FindAsync(model.Id);
            if(course==null) return Ok(new Response { state = 0, message = _localization["coursenotfound"].Value });
            if (ModelState.IsValid)
            {
                try
                {
                   course.Defination = model.Defination;
                    course.Coupon= model.Coupon;
                    course.Language = model.Language;
                    course.Price= model.Price;
                    course.Titel= model.Titel;
                    course.Trainer = model.Trainer;
                    course.Topics= model.Topics;
                    course.Lang= model.Lang;
                    
                    _context.Update(course);
                    await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["modefiedsuccessfuly"].Value, url = "/Courses/Index" });
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Ok(new Response { state = 0, message = _localization["errorinoperation"].Value });
                }
               
            }
            return Ok(new Response { state = 0, message =_localization["validateallparamaters"].Value});
        }

        // GET: Courses/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Courses
                .FirstOrDefaultAsync(m => m.Id == id);
            if (course == null)
            {
                return NotFound();
            }

            return View(course);
        }

        // POST: Courses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var course = await _context.Courses.FindAsync(id);
                if (course != null)
                {
                    _context.Courses.Remove(course);
                }else
                    return Ok(new Response { state = 0, message = _localization["coursenotfound"].Value });

                await _context.SaveChangesAsync();
                return Ok(new Response { state = 2, message = _localization["deletessuccessfuly"].Value, url = "/Courses/Index" });
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message = _localization["errorinoperation"].Value });
            }
        }

        private bool CourseExists(int id)
        {
            return _context.Courses.Any(e => e.Id == id);
        }
    }
}
