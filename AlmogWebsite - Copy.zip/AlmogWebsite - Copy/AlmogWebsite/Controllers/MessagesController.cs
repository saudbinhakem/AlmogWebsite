﻿using AlmogWebsite.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class MessagesController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<MessagesController> _localization;
        public MessagesController(AlmogdatabaseContext context, IStringLocalizer<MessagesController> _localization)
        {
            _context = context;
            this._localization = _localization;
        }
        public IActionResult Index()
        {
            var temp=_context.ContactUs.OrderBy(o=>o.OrderDate).ToList();
            return View(temp);
        }
        [HttpGet]
        public IActionResult Edit(long? id)
        {
            if (id == null) return NotFound();
            var data = _context.ContactUs.Find(id);
            return View(data);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Models.ContactU model)
        {
            if (model == null) return Ok(new { state = 0, message = _localization["fillalldata"].Value });
            var data = _context.ContactUs.Find(model.Id);
            if (data == null) return Ok(new { state = 0, message = _localization["messagenotsent"].Value });
            try
            {
                App.Helpers.MailClass mail = new App.Helpers.MailClass();
                mail.Send(new App.Entity.MailModel() { Email = data.Email, Subject = "Replay ", body = model.Replay });
                data.IsReplay = true;
                data.Replay = model.Replay;
                _context.Update(data);
                _context.SaveChanges();
                return Ok(new { state = 7, message = _localization["sendsuccessfuly"].Value, url ="/Messages/Index" });
            }
            catch (Exception ex)
            {
                return Ok(new { state = 0, message = _localization["messagenotsent"].Value });
            }



        }


    }
}
