﻿using AlmogWebsite.Models;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace AlmogWebsite.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AlmogdatabaseContext _context;
        //private readonly HttpContext context;
        private readonly IStringLocalizer<HomeController> _localization;
        public HomeController(ILogger<HomeController> logger, IStringLocalizer<HomeController> _localization, AlmogdatabaseContext _context /*, HttpContext context*/)
        {
            _logger = logger;
            this._context = _context;
            this._localization = _localization;
            //this.context= context;
        }

        public IActionResult Index()
        {
            var browserLanguage = Thread.CurrentThread.CurrentCulture.Name;
            var data = new App.Entity.IndexModel();
            var temp = _context.SiteInfos.FirstOrDefault();
            if (temp != null)
            {
                data.appAppleLink = temp.AppLinkApple;
                data.appGoogleLink = temp.AppLinkGoogle;
                if (browserLanguage.StartsWith("ar")) { data.Defination = temp.Defnition; data.Vision = temp.Vision;}
                else { data.Defination = temp.EnDefnition; data.Vision = temp.Envision; }               
                data.Email = temp.Email;
                data.Location = temp.Place;
                data.phoneNo = temp.Phone;
                data.facebook = temp.FacebookLink;
                data.Whatsapp = temp.WhatsappLink;
                data.LinkedIn = temp.LinkedInLink;
                
            }
            if (browserLanguage.StartsWith("ar"))
                data.blog = _context.Blogs.OrderBy(e => e.WriteDate).Where(p=>p.Lang=="ar").Select(i => new App.Entity.Blog { Id = i.Id, Text = i.Body,icon=i.DisplayImage!=null?   i.DisplayImage:"/assets/img/icon.png" }).Take(3).ToList();
                else data.blog = _context.Blogs.OrderBy(e => e.WriteDate).Where(p=>p.Lang=="en").Select(i => new App.Entity.Blog { Id = i.Id, Text = i.Body,icon=i.DisplayImage!=null?   i.DisplayImage:"/assets/img/icon.png" }).Take(3).ToList();
            
            data.features = _context.Features.OrderBy(e => e.Id).Select(i => new App.Entity.Features { Id = i.Id, Text =(browserLanguage.StartsWith("ar"))? i.Name:i.EnName,icon=i.Icon!=null?   i.Icon: "/assets/img/icon.png" }).Take(3).ToList();
            return View(data);
        }

        public IActionResult Privacy()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SetLanguage(string culture, string returnUrl)
        {
            Response.Cookies.Append(
                CookieRequestCultureProvider.DefaultCookieName,
                CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
                new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1) }
                );

            return LocalRedirect(returnUrl);
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> ContuctUS(App.Entity.ContactUS model)
        {

            if (!ModelState.IsValid) return Ok(new { state = 0, message = _localization["fillalldata"].Value });
            try
            {
                //Service.MailClass mail = new Service.MailClass();
                //mail.sendImailwithoutAsync(new MailModel { body=model.Message,Email=model.email,Subject=model.subject});
                var ob = new Models.ContactU();
                //ob.Subject = model.subject;
                ob.Email = model.email;
                ob.OrderDate = DateTime.Now;
                ob.PhoneNo = model.Phone;
                ob.Message = model.Message;
                ob.Name = model.Name ;
                _context.ContactUs.Add(ob);
                await _context.SaveChangesAsync();
                return Ok(new { state = 1, message = _localization["sendsuccessfuly"].Value });
            }
            catch (Exception ex)
            {
                return Ok(new { state = 0, message = _localization["messagenotsent"].Value });
            }

        }

    }
}
