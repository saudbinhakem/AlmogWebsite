﻿using AlmogWebsite.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    [Authorize]
    public class adminController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<adminController> _localization;
        public adminController(ILogger<HomeController> logger, IStringLocalizer<adminController> _localization, AlmogdatabaseContext context)
        {
            _logger = logger;
            _context = context;
            this._localization = _localization;
        }
        public IActionResult Index()
        {
            var MemberNo = 01554556;
            //ViewBag.data = " شكراَ لإنضمامك لعالم هللة بلس رقم عضويتك هو " + MemberNo + " توفيرك يبدأ بهللة... تصفح خصومات هللة في الموقع الالكتروني(https://www.halalaplus.com) ولا تنسى ابراز رقم عضويتك عند التاجر لكي تحصل على الخصم المدون";
           return View();
        }

         public IActionResult web()
        {
            var data = new App.Entity.IndexModel();
            var temp = _context.SiteInfos.FirstOrDefault();
            if (temp != null)
            {
                data.Vision = temp.Vision;
                data.EnVision = temp.Envision;
                data.appAppleLink = temp.AppLinkApple;
                data.appGoogleLink = temp.AppLinkGoogle;
                data.Defination = temp.Defnition;
                data.EnDefination = temp.EnDefnition;
                data.Email = temp.Email;
                data.Location = temp.Place;
                data.phoneNo = temp.Phone;
                data.facebook = temp.FacebookLink;
                data.Whatsapp = temp.WhatsappLink;
                data.LinkedIn = temp.LinkedInLink;


            }
           return View(data);
        }


        public async Task<IActionResult> SiteData(App.Entity.PostIndexModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (_context.SiteInfos == null)
                    {
                        var t = new SiteInfo();
                        t.Defnition = model.Defination;                       
                        t.EnDefnition = model.EnDefination;                       
                        t.Email = model.Email;
                        t.LinkedInLink = model.LinkedIn;
                        t.WhatsappLink = model.whatsapp;
                        t.FacebookLink = model.facebook;
                        t.Vision = model.Vision;
                        t.Envision = model.EnVision;
                        t.Phone = model.phoneNo;
                        _context.Add(t);
                        _context.SaveChanges();
                        return Ok(new { state = 1, message = _localization[""].Value });
                    }
                    else
                    {
                        var t = _context.SiteInfos.FirstOrDefault();
                        t.Defnition = model.Defination;
                        t.EnDefnition = model.EnDefination;
                        t.Email = model.Email;
                        t.Envision = model.EnVision;
                        t.LinkedInLink = model.LinkedIn;
                        t.WhatsappLink = model.whatsapp;
                        t.FacebookLink = model.facebook;
                        t.Vision = model.Vision;
                        t.Phone = model.phoneNo;
                        _context.Update(t);
                        _context.SaveChanges();
                        return Ok(new { state = 1, message = _localization["modefiedsuccessfuly"].Value });
                    }
                }
                catch (Exception)
                {

                    return Ok(new { state = 0, message = _localization["datanotsaved"].Value });
                }
            }
            return Ok(new { state = 0, message = _localization["datanotsaved"].Value });

        }

    }
}
