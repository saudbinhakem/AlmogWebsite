﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AlmogWebsite.Models;
using App.Entity;
using Microsoft.Extensions.Localization;

namespace AlmogWebsite.Controllers
{
    public class PackagesController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IStringLocalizer<PackagesController> _localization;
        public PackagesController(AlmogdatabaseContext context, IStringLocalizer<PackagesController> _localization)
        {
            _context = context;
            this._localization = _localization;
        }

        // GET: Packages
        public async Task<IActionResult> Index(int? m)
        {
            if(m!=null)
            ViewBag.message =m;
            return View(await _context.Packages.Where(e=>e.IsActive!=false).ToListAsync());
        }

        // GET: Packages/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                //"يجب اختيار رقم الباقة";
                ViewData["message"] = _localization["selectpackage"].Value;
                return RedirectToAction(nameof(Index),1);
            }

            var package = await _context.Packages
                .FirstOrDefaultAsync(m => m.Id == id);
            if (package == null)
            {
              //"هذه الباقة غير موجودة";
                return RedirectToAction(nameof(Index));
            }

            return View(package);
        }

        // GET: Packages/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Packages/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Characters,Price,Period,,PackageDays")] Package package)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    package.CreateOn = DateTime.Now;
                    package.IsActive = true;
                    _context.Add(package);
                    await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["addedsuccessfuly"].Value, url = "/Packages/Index" });
                }
                else { return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value }); }
               
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message = _localization["errorwillsaving1"].Value });
            }
        }

        // GET: Packages/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                ViewData["message"] = _localization["selectpackage"].Value;
                return View("Index");
            }

            var package = await _context.Packages.FindAsync(id);
            if (package == null)
            {
                ViewData["message"] = _localization["selectpackage"].Value;
                return View("Index");
            }
            return View(package);
        }

        // POST: Packages/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit( Package package)
        {
            try
            {
                var ob = await _context.Packages.FindAsync(package.Id);
                if ( ob==null)
                {
                    return NotFound();
                }

                if (ModelState.IsValid)
                {
                    try
                    {
                      ob.Characters=package.Characters;
                        ob.PackageDays = package.PackageDays;
                        ob.Period = package.Period;
                        ob.Name = package.Name;
                        ob.Price = package.Price;

                        _context.Update(ob);
                        await _context.SaveChangesAsync();
                        return Ok(new Response { state = 2, message =_localization["modefiedsuccessfuly"].Value , url = "/Packages/Index" });
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        return Ok(new Response { state = 0, message = _localization["errorwillsditing"].Value });
                    }
                    
                }
                return Ok(new Response { state = 0, message = _localization["validateallparamaters"].Value });
            }
            catch (Exception)
            {

                return Ok(new Response { state = 0, message = _localization["errorwillsaving1"].Value });
            }
        }

        // GET: Packages/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var package = await _context.Packages
                .FirstOrDefaultAsync(m => m.Id == id);
            if (package == null)
            {
                return NotFound();
            }

            return View(package);
        }

        // POST: Packages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var package = await _context.Packages.FindAsync(id);
                if (package != null)
                {
                    package.IsActive = false;
                    _context.Packages.Update(package); await _context.SaveChangesAsync();
                    return Ok(new Response { state = 2, message = _localization["deletessuccessfuly"].Value, url = "/Packages/Index" });
                }
                return Ok(new Response { state = 0, message = _localization["packagenotfound"].Value, });
            }
            catch (Exception)
            {
                return Ok(new Response { state = 0, message = _localization["errorwillsdeleting"].Value, });

            }

            
        }

        private bool PackageExists(int id)
        {
            return _context.Packages.Any(e => e.Id == id);
        }
    }
}
