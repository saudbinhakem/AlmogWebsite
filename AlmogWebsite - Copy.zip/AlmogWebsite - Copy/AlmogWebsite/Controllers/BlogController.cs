﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

using Microsoft.AspNetCore.Authorization;
using AlmogWebsite.Models;
using Microsoft.Extensions.Localization;

namespace AbdLawyerSite.Controllers
{
    //[Authorize]
    public class BlogController : Controller
    {
        private readonly AlmogdatabaseContext _context;
        private readonly IWebHostEnvironment _hosting;
        private readonly IStringLocalizer<BlogController> _localization;
        public BlogController(AlmogdatabaseContext context,IStringLocalizer<BlogController> localizer, IWebHostEnvironment hosting)
        {
            _context = context;
            _localization = localizer;
            _hosting = hosting;
        }

        // GET: Articles
        public async Task<IActionResult> Index()
        {
            var temp = _context.Blogs.Where(o=>o.Deleted!=true).Select(e=> new App.Entity.Blog {
               
                Text = e.Body,
                Lang=e.Lang,
                WriteDate  =e.WriteDate.ToString(),
                Id=e.Id,
            }).OrderBy(p=>p.WriteDate).ToList();
              return View(temp);
        }

        // GET: Articles/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Blogs == null)
            {
                return NotFound();
            }

            var article = await _context.Blogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }
           
            return View(article);
        }

        // GET: Articles/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Articles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(App.Entity.Blog article)
        {
            if (ModelState.IsValid)
            {
                var temp = new AlmogWebsite.Models.Blog();
                try
                {
                   
                    temp.Body = article.Text;
                    temp.Lang = article.Lang;
                    temp.WriteDate = DateTime.Now;
                  

                    _context.Add(temp);
                    await _context.SaveChangesAsync();
                }
                catch (Exception )
                {
                    
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(article);
        }

        // GET: Articles/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Blogs == null)
            {
                return NotFound();
            }

            var article = await _context.Blogs.FindAsync(id);
            if (article == null)
            {
                return NotFound();
            }
            var ob= new App.Entity.Blog(){ 
           
            Text=article.Body,
            Lang=article.Lang,
          
            Id=article.Id,
           
            };
            return View(ob );
        }

        // POST: Articles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(App. Entity.Blog article)
        {

            if (ModelState.IsValid)
            {
                var ob = await _context.Blogs.FindAsync(article.Id);
                if(ob == null) return View(article);
             
                try
                {
                 
                    ob.Body = article.Text;
                    ob.Lang = article.Lang;
               
                    _context.Update(ob);
                    await _context.SaveChangesAsync();
                   
                }
                catch (DbUpdateConcurrencyException)
                {
                   if (!ArticleExists(article.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(article);
        }

        // GET: Articles/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Blogs == null)
            {
                return NotFound();
            }

            var article = await _context.Blogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }
          
            return View(article);
        }

        // POST: Articles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Blogs == null)
            {
                return Problem("Entity set 'AbdLawyerDBContext.Articles'  is null.");
            }
            var article = await _context.Blogs.FindAsync(id);
            if (article != null)
            {
                _context.Blogs.Remove(article);
            }
            
            await _context.SaveChangesAsync();
          
            return RedirectToAction(nameof(Index));
        }

        private bool ArticleExists(int id)
        {
          return (_context.Blogs?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
