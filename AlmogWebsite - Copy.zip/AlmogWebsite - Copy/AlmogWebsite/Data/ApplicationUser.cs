﻿using Microsoft.AspNetCore.Identity;

namespace AlmogWebsite.Data
{
    public class ApplicationUser : IdentityUser
    {
        public string? RefreshToken { get; set; }
        public DateTime RefreshTokenExpiryTime { get; set; }
        public string? FullName { get; set; }
        //public string? ShortScrap { get; set; }
        public string? Image { get; set; }
        public string? MemberNo { get; set; }
        public string? FacePrint { get; set; }
        public string? RegisterProgress { get; set; }
        public bool? Type { get; set; }
        public bool Deleted { get; set; }
    }
}
