﻿function ShowImagePreview(imageUploader, previwImage) {
    if (imageUploader.files && imageUploader.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $(previwImage).attr('src', e.target.result);
        }
        reader.readAsDataURL(imageUploader.files[0]);
    }

};
//$(document).ready(function () {
//    $("#tryimg").on("change", function () {
//        var files = $(this)[0].files;
//        $("#imagesdiv").empty();
//        if (files.length > 0) {
//            for (var i = 0; i < files.length; i++) {
//                var reader = new FileReader();
//                reader.onload = function (e) {
//                    $("<div class='avatarimg'><img src='" + e.target.result + "'></div>").appendTo("#imagesdiv");
//                };
//                reader.readAsDataURL(files[i]);
//            }
//        }
//    });

//});

function ShowImagePreview2(imageUploader, previwImage,clear) {
    if (imageUploader.files && imageUploader.files[0]) {

        var files = $(imageUploader)[0].files;
        if (clear == 1) {  $("#imagesdiv").empty();
    }
        if (files.length > 0) {
            for (var i = 0; i < files.length; i++) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $("<div class='col-lg-4 col-md-6 portfolio-item filter-web'><div class='portfolio-wrap'><img src='" + e.target.result + "'  class='img-fluid'></div></div>").appendTo(previwImage);
                };
                reader.readAsDataURL(files[i]);
            }
        }
 
    }

};
$(".submitfm").on("submit", function (event) {
    event.preventDefault();
    var url = $(this).attr("action");

    $.ajax({
        url: url,
        type: "POST",
        dataType: "JSON",
        data: new FormData(this),
        processData: false,
        contentType: false,
        success: function (data) {
            if (data.state == 1) {
                Swal.fire({
                    title: 'نجـــاح',
                    type: 'success',
                    
                    text: data.message,
                    timer: 2500
                });

            }
            else if (data.state == 2) {
                
                Swal.fire({
                    title: 'نجـــاح',
                    html: data.message,
                    icon: "success",
                    type: "success",

                    confirmButtonText: "نعم",



                }).then((result) => {
                    if (result) {

                        codingCourse(data.url)
                    }
                });


            } else if (data.state == 5) {
                window.location.reload();
            }
           
            else if (data.state == 6) {
                window.location.reload();
            }
            else if (data.state == 7) {

                Swal.fire({

                    title: data.message,
                    icon: "success",
                    type: "success",
                   
                    confirmButtonText: "نعم",



                }).then((result) => {
                    if (result) {
                       
                        codingCourse(data.url)
                    }
                });
                
            
            }
            else {
                Swal.fire({
                    type: 'error',
                    title: 'خطاء...',
                    text: data.message,
                })
            }

        },
        error: function (xhr, desc, err) {
            Swal.fire({
                type: 'error',
                title: 'خطاء...',
                text: "هنالك خطاء تاكد من صحة البيانات",
            })
        }
    });

});



//function definition

function codingCourse(url) {
    window.location.href = url
}

function displayMessage(message) {
   
    Swal.fire({
        title: 'نجـــاح',
        type: 'success',

        text: message,
        timer: 2500
    });
}
