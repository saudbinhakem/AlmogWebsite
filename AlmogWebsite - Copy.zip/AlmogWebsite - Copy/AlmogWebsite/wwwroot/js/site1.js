﻿function displayMessage(message) {

    Swal.fire({
        title: 'نجـــاح',
        type: 'success',

        text: message,
        timer: 2500
    });
}
